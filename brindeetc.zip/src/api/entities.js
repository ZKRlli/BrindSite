import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const BlogPost = base44.entities.BlogPost;

export const QuoteRequest = base44.entities.QuoteRequest;

export const ConsultationRequest = base44.entities.ConsultationRequest;

export const Product = base44.entities.Product;

export const HeroBanner = base44.entities.HeroBanner;

export const CartItem = base44.entities.CartItem;



// auth sdk:
export const User = base44.auth;