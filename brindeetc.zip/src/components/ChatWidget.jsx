import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Loader2, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import ReactMarkdown from 'react-markdown';
import { Link } from 'react-router-dom';

const SESSION_STORAGE_KEY = 'brind_chat_session';

export default function ChatWidget({ isOpen, onClose }) {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [conversation, setConversation] = useState(null);
  const messagesEndRef = useRef(null);

  // Load session from localStorage on mount
  useEffect(() => {
    const savedSession = localStorage.getItem(SESSION_STORAGE_KEY);
    if (savedSession) {
      try {
        const { messages: savedMessages, conversationId } = JSON.parse(savedSession);
        if (savedMessages && savedMessages.length > 0) {
          setMessages(savedMessages);
        }
        if (conversationId) {
          loadExistingConversation(conversationId);
        }
      } catch (e) {
        console.error('Erro ao carregar sessão:', e);
      }
    }
  }, []);

  // Save messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify({
        messages,
        conversationId: conversation?.id
      }));
    }
  }, [messages, conversation]);

  useEffect(() => {
    if (isOpen && !conversation && messages.length === 0) {
      initConversation();
    }
  }, [isOpen]);

  const loadExistingConversation = async (conversationId) => {
    try {
      const existingConversation = await base44.agents.getConversation(conversationId);
      if (existingConversation) {
        setConversation(existingConversation);
        base44.agents.subscribeToConversation(conversationId, (data) => {
          if (data.messages && data.messages.length > 0) {
            setMessages(data.messages);
          }
          const lastMsg = data.messages?.[data.messages.length - 1];
          if (lastMsg?.role === 'assistant') {
            setIsLoading(false);
          }
        });
      }
    } catch (error) {
      console.error('Erro ao carregar conversa existente:', error);
      initConversation();
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const initConversation = async () => {
    try {
      const newConversation = await base44.agents.createConversation({
        agent_name: "atendimento",
        metadata: {
          name: "Chat do Site",
          description: "Conversa iniciada pelo widget do site"
        }
      });
      setConversation(newConversation);
      
      // Add welcome message
      setMessages([{
        role: 'assistant',
        content: 'Olá! 🎀 Seja bem-vindo(a) à Brind.etc! Sou sua assistente virtual e estou aqui para ajudar com dúvidas sobre nossos produtos, serviços e orçamentos. Como posso te ajudar hoje?'
      }]);

      // Subscribe to updates
      base44.agents.subscribeToConversation(newConversation.id, (data) => {
        setMessages(data.messages || []);
        const lastMsg = data.messages?.[data.messages.length - 1];
        if (lastMsg?.role === 'assistant') {
          setIsLoading(false);
        }
      });
    } catch (error) {
      console.error('Erro ao iniciar conversa:', error);
      setMessages([{
        role: 'assistant',
        content: 'Olá! Estou aqui para ajudar. Como posso te auxiliar hoje?'
      }]);
    }
  };

  const handleSend = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage = inputValue.trim();
    setInputValue('');
    setIsLoading(true);

    // Add user message immediately
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);

    try {
      if (conversation) {
        await base44.agents.addMessage(conversation, {
          role: 'user',
          content: userMessage
        });
      }
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: 'Desculpe, ocorreu um erro. Por favor, entre em contato pelo WhatsApp: +55 11 99814-8242'
      }]);
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.9 }}
        className="fixed bottom-24 right-6 w-[360px] h-[500px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden z-50 border border-gray-200"
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-pink-500 to-purple-500 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Assistente Brind.etc</h3>
              <p className="text-white/80 text-xs">Online agora</p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-white hover:bg-white/20"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                  msg.role === 'user'
                    ? 'bg-gradient-to-r from-pink-500 to-purple-500 text-white rounded-br-md'
                    : 'bg-white text-gray-800 shadow-sm border border-gray-100 rounded-bl-md'
                }`}
              >
                {msg.role === 'assistant' ? (
                  <ReactMarkdown 
                    className="text-sm prose prose-sm max-w-none [&>*:first-child]:mt-0 [&>*:last-child]:mb-0 [&_a]:text-pink-600 [&_a]:underline [&_a]:font-medium"
                    components={{
                      a: ({ href, children }) => {
                        // Check if it's an internal link
                        if (href?.startsWith('/')) {
                          return (
                            <Link 
                              to={href} 
                              className="text-pink-600 underline font-medium hover:text-pink-700"
                              onClick={onClose}
                            >
                              {children}
                            </Link>
                          );
                        }
                        return (
                          <a href={href} target="_blank" rel="noopener noreferrer" className="text-pink-600 underline font-medium hover:text-pink-700">
                            {children}
                          </a>
                        );
                      }
                    }}
                  >
                    {msg.content}
                  </ReactMarkdown>
                ) : (
                  <p className="text-sm">{msg.content}</p>
                )}
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white rounded-2xl rounded-bl-md px-4 py-3 shadow-sm border border-gray-100">
                <div className="flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin text-pink-500" />
                  <span className="text-sm text-gray-500">Digitando...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 bg-white border-t border-gray-100">
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Digite sua mensagem..."
              className="flex-1 rounded-full border-gray-200 focus:border-pink-500 focus:ring-pink-500"
              disabled={isLoading}
            />
            <Button
              onClick={handleSend}
              disabled={!inputValue.trim() || isLoading}
              className="rounded-full bg-gradient-to-r from-pink-500 to-purple-500 hover:opacity-90 px-4"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-xs text-gray-400 text-center mt-2">
            Powered by Brind.etc AI
          </p>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}