import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Phone, Bot } from 'lucide-react';
import ChatWidget from './ChatWidget';

const WHATSAPP_NUMBER = "5511998148242";
const WHATSAPP_MESSAGE = encodeURIComponent("Olá! Vim pelo site e gostaria de mais informações.");
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`;

export default function FloatingContactButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  const handleOptionClick = (option) => {
    if (option === 'chat') {
      setIsChatOpen(true);
      setIsOpen(false);
    }
  };

  const options = [
    {
      icon: Bot,
      label: "Assistente IA",
      description: "Tire suas dúvidas",
      action: () => handleOptionClick('chat'),
      bgColor: "bg-gradient-to-r from-pink-500 to-purple-500 hover:opacity-90"
    },
    {
      icon: Phone,
      label: "WhatsApp",
      description: "Fale conosco",
      href: WHATSAPP_LINK,
      bgColor: "bg-green-500 hover:bg-green-600",
      external: true
    }
  ];

  return (
    <>
      {/* Chat Widget */}
      <ChatWidget isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

      <div className="fixed bottom-6 right-6 z-50">
        <AnimatePresence>
          {isOpen && !isChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.8 }}
              transition={{ duration: 0.2 }}
              className="absolute bottom-16 right-0 mb-2 flex flex-col gap-3"
            >
              {options.map((option, index) => (
                option.href ? (
                  <motion.a
                    key={option.label}
                    href={option.href}
                    target={option.external ? "_blank" : "_self"}
                    rel={option.external ? "noopener noreferrer" : undefined}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`flex items-center gap-3 px-4 py-3 rounded-full shadow-lg text-white ${option.bgColor} transition-all hover:scale-105`}
                  >
                    <option.icon className="h-5 w-5" />
                    <div className="text-left whitespace-nowrap">
                      <p className="font-semibold text-sm">{option.label}</p>
                      <p className="text-xs opacity-90">{option.description}</p>
                    </div>
                  </motion.a>
                ) : (
                  <motion.button
                    key={option.label}
                    onClick={option.action}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`flex items-center gap-3 px-4 py-3 rounded-full shadow-lg text-white ${option.bgColor} transition-all hover:scale-105`}
                  >
                    <option.icon className="h-5 w-5" />
                    <div className="text-left whitespace-nowrap">
                      <p className="font-semibold text-sm">{option.label}</p>
                      <p className="text-xs opacity-90">{option.description}</p>
                    </div>
                  </motion.button>
                )
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Button */}
        {!isChatOpen && (
          <motion.button
            onClick={() => setIsOpen(!isOpen)}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className={`w-14 h-14 rounded-full shadow-xl flex items-center justify-center transition-all ${
              isOpen 
                ? 'bg-gray-700 hover:bg-gray-800' 
                : 'bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600'
            }`}
          >
            <AnimatePresence mode="wait">
              {isOpen ? (
                <motion.div
                  key="close"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <X className="h-6 w-6 text-white" />
                </motion.div>
              ) : (
                <motion.div
                  key="open"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <MessageCircle className="h-6 w-6 text-white" />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>
        )}

        {/* Pulse animation when closed */}
        {!isOpen && !isChatOpen && (
          <span className="absolute inset-0 rounded-full bg-pink-500 animate-ping opacity-25 pointer-events-none"></span>
        )}
      </div>
    </>
  );
}