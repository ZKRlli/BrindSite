import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  ShoppingCart, Package, Weight,
  Palette, Info, Plus, Minus, AlertCircle, CheckCircle
} from 'lucide-react';
import { base44 } from '@/api/base44Client';

const SPOTGIFTS_IMAGE_BASE = 'https://www.spotgifts.com.br/fotos/produtos/';

const getProductImageUrl = (imageUrl) => {
  if (!imageUrl) {
    return 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60';
  }
  if (imageUrl.startsWith('http')) {
    return imageUrl;
  }
  return `${SPOTGIFTS_IMAGE_BASE}${imageUrl}`;
};

// Função para gerar URLs de variações de imagem do mesmo produto
const generateProductImageVariations = (product) => {
  if (!product || !product.ProdReference) return [];
  
  const baseRef = product.ProdReference;
  const variations = [];
  
  // Padrão 1: Sufixos simples de letras (99969_a.jpg, 99969_b.jpg, etc.)
  const letterSuffixes = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'];
  letterSuffixes.forEach(letter => {
    variations.push(`${baseRef}_${letter}.jpg`);
  });
  
  // Padrão 2: Números comuns (99969_108.jpg, 99969_119.jpg, etc.)
  // Testar códigos de cores comuns de 100 a 150
  for (let i = 100; i <= 150; i++) {
    variations.push(`${baseRef}_${i}.jpg`);
    // Também testar com sufixos -a, -b, -c após o número
    variations.push(`${baseRef}_${i}-a.jpg`);
    variations.push(`${baseRef}_${i}-b.jpg`);
    variations.push(`${baseRef}_${i}-c.jpg`);
  }
  
  // Padrão 3: Variações especiais (logo, front, back, etc.)
  const specialSuffixes = ['logo', 'front', 'back', 'detail', 'close'];
  specialSuffixes.forEach(suffix => {
    variations.push(`${baseRef}_${suffix}.jpg`);
  });
  
  // Converter para URLs completas
  return variations.map(filename => getProductImageUrl(filename));
};

// Mapa de cores padrão baseado em nomes comuns
const getColorHex = (colorName) => {
  const colorMap = {
    // Cores básicas
    'branco': '#FFFFFF',
    'preto': '#000000',
    'cinza': '#808080',
    'vermelho': '#FF0000',
    'azul': '#0000FF',
    'verde': '#00FF00',
    'amarelo': '#FFFF00',
    'laranja': '#FFA500',
    'rosa': '#FFC0CB',
    'roxo': '#800080',
    'marrom': '#8B4513',
    'bege': '#F5F5DC',

    // Variações em inglês
    'white': '#FFFFFF',
    'black': '#000000',
    'grey': '#808080',
    'gray': '#808080',
    'red': '#FF0000',
    'blue': '#0000FF',
    'green': '#00FF00',
    'yellow': '#FFFF00',
    'orange': '#FFA500',
    'pink': '#FFC0CB',
    'purple': '#800080',
    'brown': '#8B4513',
    'navy': '#000080',
    'lime': '#32CD32',
    'silver': '#C0C0C0',
    'gold': '#FFD700',
    'beige': '#F5F5DC',

    // Cores específicas - tons escuros
    'azul marinho': '#000080',
    'azul royal': '#4169E1',
    'azul escuro': '#00008B',
    'verde escuro': '#006400',
    'vermelho escuro': '#8B0000',
    'cinza escuro': '#A9A9A9',
    'amarelo escuro': '#B8860B',
    'laranja escuro': '#FF8C00',
    'rosa escuro': '#C71585',
    'roxo escuro': '#4B0082',
    'marrom escuro': '#654321',

    // Cores específicas - tons claros
    'azul claro': '#ADD8E6',
    'verde claro': '#90EE90',
    'vermelho claro': '#FF6B6B',
    'cinza claro': '#D3D3D3',
    'amarelo claro': '#FFFFE0',
    'laranja claro': '#FFDAB9',
    'rosa claro': '#FFB6C1',
    'roxo claro': '#DDA0DD',
    'marrom claro': '#D2B48C',

    // Variações em inglês - tons claros
    'light blue': '#ADD8E6',
    'light green': '#90EE90',
    'light red': '#FF6B6B',
    'light gray': '#D3D3D3',
    'light grey': '#D3D3D3',
    'light yellow': '#FFFFE0',
    'light orange': '#FFDAB9',
    'light pink': '#FFB6C1',
    'light purple': '#DDA0DD',
    'light brown': '#D2B48C',

    // Variações em inglês - tons escuros
    'dark blue': '#00008B',
    'dark green': '#006400',
    'dark red': '#8B0000',
    'dark gray': '#A9A9A9',
    'dark grey': '#A9A9A9',
    'dark yellow': '#B8860B',
    'dark orange': '#FF8C00',
    'dark pink': '#C71585',
    'dark purple': '#4B0082',
    'dark brown': '#654321',

    // Tons de azul
    'azul celeste': '#87CEEB',
    'azul turquesa': '#40E0D0',
    'azul petróleo': '#008B8B',
    'sky blue': '#87CEEB',
    'turquoise': '#40E0D0',
    'teal': '#008080',
    'cyan': '#00FFFF',
    'aqua': '#00FFFF',

    // Tons de verde
    'verde limão': '#32CD32',
    'verde musgo': '#8FBC8F',
    'verde oliva': '#808000',
    'lime green': '#32CD32',
    'olive': '#808000',
    'mint': '#98FF98',

    // Tons de vermelho
    'vermelho vinho': '#722F37',
    'coral': '#FF7F50',
    'carmesim': '#DC143C',
    'crimson': '#DC143C',
    'burgundy': '#800020',

    // Tons neutros
    'creme': '#FFFDD0',
    'marfim': '#FFFFF0',
    'off white': '#FAF9F6',
    'cream': '#FFFDD0',
    'ivory': '#FFFFF0',

    // Tons metálicos
    'dourado': '#FFD700',
    'prateado': '#C0C0C0',
    'bronze': '#CD7F32',
    'cobre': '#B87333',
  };

  const normalizedName = colorName?.toLowerCase().trim() || '';

  // Verificar primeiro no mapa direto
  if (colorMap[normalizedName]) {
    return colorMap[normalizedName];
  }

  // Lógica inteligente para detectar padrões "X claro" ou "light X"
  const lightPatternPt = normalizedName.match(/^(.+)\s+claro$/);
  if (lightPatternPt) {
    const baseColor = lightPatternPt[1];
    const lightColorMap = {
      'azul': '#ADD8E6',
      'verde': '#90EE90',
      'vermelho': '#FF6B6B',
      'amarelo': '#FFFFE0',
      'laranja': '#FFDAB9',
      'rosa': '#FFB6C1',
      'roxo': '#DDA0DD',
      'marrom': '#D2B48C',
      'cinza': '#D3D3D3',
    };
    if (lightColorMap[baseColor]) {
      return lightColorMap[baseColor];
    }
  }

  const lightPatternEn = normalizedName.match(/^light\s+(.+)$/);
  if (lightPatternEn) {
    const baseColor = lightPatternEn[1];
    const lightColorMap = {
      'blue': '#ADD8E6',
      'green': '#90EE90',
      'red': '#FF6B6B',
      'yellow': '#FFFFE0',
      'orange': '#FFDAB9',
      'pink': '#FFB6C1',
      'purple': '#DDA0DD',
      'brown': '#D2B48C',
      'gray': '#D3D3D3',
      'grey': '#D3D3D3',
    };
    if (lightColorMap[baseColor]) {
      return lightColorMap[baseColor];
    }
  }

  // Lógica inteligente para detectar padrões "X escuro" ou "dark X"
  const darkPatternPt = normalizedName.match(/^(.+)\s+escuro$/);
  if (darkPatternPt) {
    const baseColor = darkPatternPt[1];
    const darkColorMap = {
      'azul': '#00008B',
      'verde': '#006400',
      'vermelho': '#8B0000',
      'amarelo': '#B8860B',
      'laranja': '#FF8C00',
      'rosa': '#C71585',
      'roxo': '#4B0082',
      'marrom': '#654321',
      'cinza': '#A9A9A9',
    };
    if (darkColorMap[baseColor]) {
      return darkColorMap[baseColor];
    }
  }

  const darkPatternEn = normalizedName.match(/^dark\s+(.+)$/);
  if (darkPatternEn) {
    const baseColor = darkPatternEn[1];
    const darkColorMap = {
      'blue': '#00008B',
      'green': '#006400',
      'red': '#8B0000',
      'yellow': '#B8860B',
      'orange': '#FF8C00',
      'pink': '#C71585',
      'purple': '#4B0082',
      'brown': '#654321',
      'gray': '#A9A9A9',
      'grey': '#A9A9A9',
    };
    if (darkColorMap[baseColor]) {
      return darkColorMap[baseColor];
    }
  }

  return '#CCCCCC'; // Cor padrão se não encontrar
};

const customizationTechniques = [
  { code: "DGL", title: "Impressão Digital", description: "Impressão com qualidade fotográfica" },
  { code: "EDB", title: "Bordado", description: "Personaliza tecidos com acabamento sofisticado" },
  { code: "LSR", title: "Laser", description: "Gravação de alta precisão em baixo-relevo" },
  { code: "DTT", title: "Transfer Digital", description: "Aplicação por calor e pressão em full color" },
  { code: "HTS", title: "Hot Stamping", description: "Prensa quente com acabamento metalizado" },
  { code: "PDP", title: "Tampografia", description: "Ideal para pequenos objetos e formas curvas" },
  { code: "DUV", title: "UV Digital", description: "Impressão direta com secagem instantânea" },
  { code: "LAS", title: "Laser Circular", description: "Gravação para superfícies curvas" },
  { code: "SCR", title: "Silk Screen", description: "Cores sólidas e vibrantes" },
  { code: "TRS", title: "Transfer", description: "Para produtos não planos" },
  { code: "SUB", title: "Sublimação", description: "Cores vivas e duradouras" },
];

// Função para gerar referência customizada (oculta o código do fornecedor)
const generateDisplayReference = (product) => {
  // Usa o ID interno do produto para gerar uma referência única
  // Formato: BE-XXXX (Brind.etc + código numérico)
  if (!product.id) {
    return `BE-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
  }

  // Criar código baseado no ID (sempre consistente para o mesmo produto)
  const idStr = product.id.toString();
  // Ensure numericPart is at least 4 digits, padding with '0' if ID is short
  const numericPart = idStr.slice(-4).padStart(4, '0');
  return `BE-${numericPart}`;
};

export default function ProductDetailModal({ product, isOpen, onClose, editingCartItem }) {
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedColor, setSelectedColor] = useState(null);
  const [selectedCustomization, setSelectedCustomization] = useState(null);
  const [notes, setNotes] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [addSuccess, setAddSuccess] = useState(false);
  const [availableImages, setAvailableImages] = useState([]); // Valid product images
  const [loadingImages, setLoadingImages] = useState(true);

  useEffect(() => {
    if (isOpen && product) {
      // Reset states
      setSelectedImage(0);
      setAddSuccess(false);
      setAvailableImages([]);
      setLoadingImages(true);

      if (editingCartItem) {
        setQuantity(editingCartItem.quantity);
        setSelectedColor(editingCartItem.selected_color);
        setSelectedCustomization(editingCartItem.selected_customization);
        setNotes(editingCartItem.notes || '');
      } else {
        setQuantity(1);
        const defaultColor = product.Colors && product.Colors.length > 0 ? product.Colors[0] : null;
        setSelectedColor(defaultColor);
        setSelectedCustomization(null);
        setNotes('');
      }

      loadProductImages();
    }
  }, [isOpen, product, editingCartItem]);

  const loadProductImages = async () => {
    if (!product) return;

    const mainImage = getProductImageUrl(product.MainImage || product.image_url);
    const validImages = [mainImage]; // Always include the main image

    // Adicionar imagens adicionais se existirem
    if (product.AditionalImageList && Array.isArray(product.AditionalImageList)) {
      product.AditionalImageList.forEach(img => {
        const fullUrl = getProductImageUrl(img);
        if (!validImages.includes(fullUrl)) {
          validImages.push(fullUrl);
        }
      });
    }

    // Tentar carregar variações de imagem
    const variations = generateProductImageVariations(product);
    
    // Verificar quais variações existem (em lotes para melhor performance)
    const batchSize = 10;
    for (let i = 0; i < variations.length; i += batchSize) {
      const batch = variations.slice(i, i + batchSize);
      const imageChecks = batch.map(url => 
        new Promise((resolve) => {
          const img = new Image();
          const timeoutId = setTimeout(() => resolve({ url, valid: false }), 1500); // 1.5-second timeout
          img.onload = () => {
            clearTimeout(timeoutId);
            resolve({ url, valid: true });
          };
          img.onerror = () => {
            clearTimeout(timeoutId);
            resolve({ url, valid: false });
          };
          img.src = url;
        })
      );

      try {
        const results = await Promise.all(imageChecks);
        results.forEach(({ url, valid }) => {
          if (valid && !validImages.includes(url)) {
            validImages.push(url);
          }
        });
      } catch (error) {
        console.error('Erro ao verificar lote de imagens:', error);
      }
    }

    setAvailableImages(validImages);
    setLoadingImages(false);
  };

  if (!product) return null;

  const displayReference = generateDisplayReference(product);
  
  const handleQuantityChange = (delta) => {
    const newQty = Math.max(1, Math.min(999, quantity + delta));
    setQuantity(newQty);
  };

  const getSessionId = () => {
    let sessionId = localStorage.getItem('cart_session_id');
    if (!sessionId) {
      sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
      localStorage.setItem('cart_session_id', sessionId);
    }
    return sessionId;
  };

  const handleAddToCart = async () => {
    setIsAdding(true);
    
    try {
      const currentImage = availableImages[selectedImage] || availableImages[0];
      const cartItemData = {
        product_reference: product.ProdReference,
        product_name: product.Name,
        product_image: currentImage,
        product_description: product.Description || product.description || '',
        quantity: quantity,
        selected_color: selectedColor,
        selected_customization: selectedCustomization,
        session_id: getSessionId(),
        notes: notes
      };

      if (editingCartItem) {
        await base44.entities.CartItem.update(editingCartItem.id, cartItemData);
      } else {
        await base44.entities.CartItem.create(cartItemData);
        const currentCount = parseInt(localStorage.getItem('cart_count') || '0');
        localStorage.setItem('cart_count', (currentCount + 1).toString());
      }
      
      window.dispatchEvent(new Event('cartUpdated'));
      setAddSuccess(true);
      
      setTimeout(() => {
        setAddSuccess(false);
        onClose();
      }, 1500);
      
    } catch (error) {
      console.error('Erro ao adicionar/atualizar o carrinho:', error);
      alert('Erro ao adicionar/atualizar o carrinho. Por favor, tente novamente.');
    } finally {
      setIsAdding(false);
    }
  };

  // Function to select color (does not directly change the main image anymore,
  // as the main image selection is independent and driven by `availableImages`)
  const handleColorSelect = (color) => {
    setSelectedColor(color);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-serif text-charcoal pr-8">
            {product.Name || product.name}
          </DialogTitle>
        </DialogHeader>

        {addSuccess && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3 mb-4">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <span className="text-green-800 font-medium">
              {editingCartItem ? 'Produto atualizado com sucesso!' : 'Produto adicionado ao carrinho com sucesso!'}
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-4">
          {/* Left Column - Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-gray-50 rounded-lg overflow-hidden border relative">
              {loadingImages ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                </div>
              ) : (
                <>
                  <img
                    src={availableImages[selectedImage] || availableImages[0]}
                    alt={product.Name || product.name}
                    className="w-full h-full object-contain p-4"
                    onError={(e) => { 
                      e.currentTarget.src = 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60'; 
                    }}
                  />
                  {availableImages.length > 1 && (
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                      {selectedImage + 1} / {availableImages.length}
                    </div>
                  )}
                </>
              )}
            </div>

            {!loadingImages && availableImages.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {availableImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`aspect-square bg-gray-50 rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === idx ? 'border-primary ring-2 ring-primary/20' : 'border-transparent hover:border-gray-300'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.Name || product.name} - ${idx + 1}`}
                      className="w-full h-full object-contain p-2"
                      onError={(e) => { 
                        // Hide broken image thumbnails
                        e.currentTarget.style.display = 'none';
                      }}
                    />
                  </button>
                ))}
              </div>
            )}

            {!loadingImages && availableImages.length > 1 && (
              <p className="text-xs text-center text-gray-500">
                ✨ {availableImages.length} imagens disponíveis deste produto
              </p>
            )}
          </div>

          {/* Right Column - Details */}
          <div className="space-y-6">
            {/* Product Info */}
            <div>
              <p className="text-sm text-gray-500 mb-2">
                Referência: <span className="font-mono">{displayReference}</span>
              </p>

              {product.Brand && (
                <Badge variant="outline" className="mb-4 bg-blue-50 text-blue-700 border-blue-200">
                  {product.Brand}
                </Badge>
              )}

              {(product.Description || product.description) && (
                <p className="text-gray-700 leading-relaxed">
                  {product.Description || product.description}
                </p>
              )}
            </div>

            <Separator />

            {/* Color Selection */}
            {product.Colors && product.Colors.length > 0 && (
              <div>
                <Label className="text-sm font-semibold mb-3 block">
                  Selecione a Cor:
                </Label>
                <div className="grid grid-cols-6 gap-3">
                  {product.Colors.map((color, idx) => {
                    const colorHex = color.HexCode || getColorHex(color.Name);
                    return (
                      <button
                        key={idx}
                        onClick={() => handleColorSelect(color)}
                        className={`group relative aspect-square rounded-lg border-2 transition-all hover:scale-110 ${
                          selectedColor?.Name === color.Name ? 'border-primary ring-2 ring-primary/20' : 'border-gray-300'
                        }`}
                        title={color.Name}
                      >
                        <div 
                          className="w-full h-full rounded-md"
                          style={{ backgroundColor: colorHex }}
                        />
                        {selectedColor?.Name === color.Name && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <CheckCircle className="h-6 w-6 text-white drop-shadow-lg" style={{
                              filter: 'drop-shadow(0 0 2px rgba(0,0,0,0.5))'
                            }} />
                          </div>
                        )}
                        <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-xs text-gray-600 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                          {color.Name}
                        </span>
                      </button>
                    );
                  })}
                </div>
                {selectedColor && (
                  <p className="text-sm text-gray-600 mt-6">
                    Cor selecionada: <span className="font-medium text-charcoal">{selectedColor.Name}</span>
                  </p>
                )}
              </div>
            )}

            <Separator />

            {/* Specifications */}
            <Tabs defaultValue="specs" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="specs">Especificações</TabsTrigger>
                <TabsTrigger value="customization">Personalização</TabsTrigger>
              </TabsList>

              <TabsContent value="specs" className="space-y-3 mt-4">
                {product.WeightGr && (
                  <div className="flex items-center gap-2">
                    <Weight className="h-4 w-4 text-gray-400" />
                    <span className="text-sm"><strong>Peso:</strong> {product.WeightGr}g</span>
                  </div>
                )}

                {product.Materials && (
                  <div className="flex items-center gap-2">
                    <Palette className="h-4 w-4 text-gray-400" />
                    <span className="text-sm"><strong>Materiais:</strong> {product.Materials}</span>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="customization" className="mt-4 space-y-4">
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 flex gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-amber-800">
                    <p className="font-semibold mb-1">Aviso Importante:</p>
                    <p>A personalização sugerida passará por avaliação de viabilidade técnica pela nossa equipe. Entraremos em contato para confirmar.</p>
                  </div>
                </div>

                <div>
                  <Label className="text-sm font-semibold mb-3 block">Técnicas de Personalização Disponíveis:</Label>
                  <RadioGroup value={selectedCustomization?.code} onValueChange={(code) => {
                    const tech = customizationTechniques.find(t => t.code === code);
                    setSelectedCustomization(tech);
                  }}>
                    <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                      {customizationTechniques.map((tech) => (
                        <div key={tech.code} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 border border-gray-200">
                          <RadioGroupItem value={tech.code} id={tech.code} className="mt-1" />
                          <Label htmlFor={tech.code} className="flex-1 cursor-pointer">
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-sm">{tech.title}</span>
                              <Badge variant="outline" className="text-xs">{tech.code}</Badge>
                            </div>
                            <p className="text-xs text-gray-600">{tech.description}</p>
                          </Label>
                        </div>
                      ))}
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="notes" className="text-sm font-semibold mb-2 block">
                    Observações sobre a personalização (opcional):
                  </Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Descreva detalhes sobre a personalização desejada: cores, posição, tamanho, arte, etc."
                    rows={3}
                    className="text-sm"
                  />
                </div>
              </TabsContent>
            </Tabs>

            <Separator />

            {/* Actions */}
            <div className="space-y-4">
              {/* Quantity Selector */}
              <div className="flex items-center gap-4">
                <span className="text-sm font-semibold">Quantidade:</span>
                <div className="flex items-center border rounded-lg">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleQuantityChange(-1)}
                    className="h-10 w-10"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <input
                    type="text"
                    value={quantity}
                    readOnly
                    className="w-16 text-center border-x focus:outline-none"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleQuantityChange(1)}
                    className="h-10 w-10"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Action Button */}
              <Button
                onClick={handleAddToCart}
                disabled={isAdding || addSuccess}
                className="w-full bg-primary hover:bg-primary/90"
                size="lg"
              >
                {isAdding ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    {editingCartItem ? 'Atualizando...' : 'Adicionando...'}
                  </>
                ) : addSuccess ? (
                  <>
                    <CheckCircle className="mr-2 h-5 w-5" />
                    {editingCartItem ? 'Atualizado!' : 'Adicionado!'}
                  </>
                ) : (
                  <>
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    {editingCartItem ? 'Atualizar Carrinho' : 'Adicionar ao Carrinho'}
                  </>
                )}
              </Button>

              {/* Additional Info */}
              <div className="bg-gray-50 rounded-lg p-4 text-sm text-gray-600 space-y-1">
                <p>💼 Ideal para brindes corporativos</p>
                <p>🎨 Personalização disponível</p>
                <p>📦 Entrega para todo o Brasil</p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}