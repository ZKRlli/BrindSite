
import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star, ShoppingCart } from 'lucide-react'; // Added ShoppingCart import
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';

const SPOTGIFTS_IMAGE_BASE = 'https://www.spotgifts.com.br/fotos/produtos/';

const getProductImageUrl = (imageUrl) => {
  if (!imageUrl) return 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60';
  if (imageUrl.startsWith('http')) return imageUrl;
  return `${SPOTGIFTS_IMAGE_BASE}${imageUrl}`;
};

// Adicionar função de conversão de cores
const getColorHex = (colorName) => {
  const colorMap = {
    'branco': '#FFFFFF', 'preto': '#000000', 'cinza': '#808080',
    'vermelho': '#FF0000', 'azul': '#0000FF', 'verde': '#00FF00',
    'amarelo': '#FFFF00', 'laranja': '#FFA500', 'rosa': '#FFC0CB',
    'roxo': '#800080', 'marrom': '#8B4513', 'bege': '#F5F5DC',
    'white': '#FFFFFF', 'black': '#000000', 'grey': '#808080', 'gray': '#808080',
    'red': '#FF0000', 'blue': '#0000FF', 'green': '#00FF00',
    'yellow': '#FFFF00', 'orange': '#FFA500', 'pink': '#FFC0CB',
    'purple': '#800080', 'brown': '#8B4513', 'navy': '#000080',
    'azul claro': '#ADD8E6', 'verde claro': '#90EE90', 'rosa claro': '#FFB6C1',
    'light blue': '#ADD8E6', 'light green': '#90EE90', 'light pink': '#FFB6C1',
    'azul escuro': '#00008B', 'verde escuro': '#006400',
    'dark blue': '#00008B', 'dark green': '#006400',
    'dourado': '#FFD700', 'prateado': '#C0C0C0',
  };
  
  const normalizedName = colorName?.toLowerCase().trim() || '';
  if (colorMap[normalizedName]) return colorMap[normalizedName];
  
  // Padrão "X claro"
  const lightMatch = normalizedName.match(/^(.+)\s+claro$/);
  if (lightMatch) {
    const base = { 'azul': '#ADD8E6', 'verde': '#90EE90', 'rosa': '#FFB6C1' };
    if (base[lightMatch[1]]) return base[lightMatch[1]];
  }
  
  return '#CCCCCC';
};

// Função para gerar referência customizada
const generateDisplayReference = (product) => {
  if (!product.id) {
    return `BE-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
  }
  const idStr = product.id.toString();
  const numericPart = idStr.slice(-4).padStart(4, '0');
  return `BE-${numericPart}`;
};

export default function ProductCarousel({ products, onViewDetails }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [direction, setDirection] = useState(0);

  useEffect(() => {
    // Select 10 random products or featured products
    if (products.length > 0) {
      const featured = products.filter(p => p.featured);
      if (featured.length >= 10) {
        setFeaturedProducts(featured.slice(0, 10));
      } else {
        // Mix featured with random products
        const shuffled = [...products].sort(() => 0.5 - Math.random());
        const selected = [...featured, ...shuffled.filter(p => !p.featured)].slice(0, 10);
        setFeaturedProducts(selected);
      }
    }
  }, [products]);

  useEffect(() => {
    if (featuredProducts.length === 0) return;
    
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % featuredProducts.length);
    }, 4000);
    
    return () => clearInterval(timer);
  }, [featuredProducts.length]);

  const goToPrevious = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + featuredProducts.length) % featuredProducts.length);
  };

  const goToNext = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % featuredProducts.length);
  };

  if (featuredProducts.length === 0) return null;

  const variants = {
    enter: (direction) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0
    })
  };

  const currentProduct = featuredProducts[currentIndex];
  const displayReference = generateDisplayReference(currentProduct);

  return (
    <div className="relative bg-gradient-to-br from-primary/5 to-purple-50 rounded-xl overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-8">
        {/* Image Side */}
        <div className="relative aspect-square bg-white rounded-lg overflow-hidden cursor-pointer" onClick={() => onViewDetails(currentProduct)}>
          <AnimatePresence initial={false} custom={direction}>
            <motion.img
              key={currentIndex}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{
                x: { type: "spring", stiffness: 300, damping: 30 },
                opacity: { duration: 0.2 }
              }}
              src={getProductImageUrl(currentProduct.MainImage)}
              alt={currentProduct.Name}
              className="absolute w-full h-full object-contain p-8"
              onError={(e) => { 
                e.currentTarget.src = 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60'; 
              }}
            />
          </AnimatePresence>

          {currentProduct.featured && (
            <Badge className="absolute top-4 right-4 bg-yellow-500 text-white border-0">
              <Star className="h-3 w-3 mr-1" />
              Destaque
            </Badge>
          )}
        </div>

        {/* Info Side */}
        <div className="flex flex-col justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <p className="text-sm text-primary font-semibold mb-2">
                Ref: {displayReference}
              </p>
              
              <h3 className="font-serif text-3xl font-bold text-charcoal mb-4 cursor-pointer hover:text-primary transition-colors" onClick={() => onViewDetails(currentProduct)}>
                {currentProduct.Name}
              </h3>

              {currentProduct.Description && (
                <p className="text-gray-600 mb-6 line-clamp-3">
                  {currentProduct.Description}
                </p>
              )}

              <div className="flex flex-wrap gap-2 mb-6">
                {currentProduct.Brand && (
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {currentProduct.Brand}
                  </Badge>
                )}
                {currentProduct.Type && (
                  <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                    {currentProduct.Type}
                  </Badge>
                )}
                {currentProduct.AvailableGross > 0 && (
                  <Badge className="bg-green-500 text-white">
                    {currentProduct.AvailableGross} unidades disponíveis
                  </Badge>
                )}
              </div>

              {/* Colors - AGORA COM getColorHex */}
              {currentProduct.Colors && currentProduct.Colors.length > 0 && (
                <div className="mb-6">
                  <p className="text-sm text-gray-600 mb-2">Cores disponíveis:</p>
                  <div className="flex flex-wrap gap-2">
                    {currentProduct.Colors.slice(0, 10).map((color, idx) => {
                      const colorHex = color.HexCode || getColorHex(color.Name);
                      return (
                        <div
                          key={idx}
                          className="w-8 h-8 rounded-full border-2 border-gray-300 shadow-sm"
                          style={{ backgroundColor: colorHex }}
                          title={color.Name}
                        />
                      );
                    })}
                    {currentProduct.Colors.length > 10 && (
                      <span className="text-sm text-gray-500 self-center">
                        +{currentProduct.Colors.length - 10} cores
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Botão Ver Detalhes */}
              <Button
                onClick={() => onViewDetails(currentProduct)}
                className="bg-primary hover:bg-primary/90 text-white mb-6"
                size="lg"
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                Ver Detalhes e Adicionar
              </Button>
            </motion.div>
          </AnimatePresence>

          {/* Controls */}
          <div className="flex items-center justify-between mt-6">
            <div className="flex gap-2">
              <Button
                onClick={goToPrevious}
                variant="outline"
                size="icon"
                className="rounded-full"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                onClick={goToNext}
                variant="outline"
                size="icon"
                className="rounded-full"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            <div className="flex gap-1">
              {featuredProducts.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setDirection(idx > currentIndex ? 1 : -1);
                    setCurrentIndex(idx);
                  }}
                  className={`h-2 rounded-full transition-all ${
                    idx === currentIndex 
                      ? 'bg-primary w-8' 
                      : 'bg-gray-300 w-2 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
