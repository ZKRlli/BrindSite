
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const SPOTGIFTS_IMAGE_BASE = 'https://www.spotgifts.com.br/fotos/produtos/';

const getProductImageUrl = (imageUrl) => {
  if (!imageUrl) {
    return 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60';
  }
  
  // Se já é uma URL completa (começa com http), retorna como está
  if (imageUrl.startsWith('http')) {
    return imageUrl;
  }
  
  // Se é apenas um nome de arquivo, construir a URL completa
  return `${SPOTGIFTS_IMAGE_BASE}${imageUrl}`;
};

// Função para gerar referência customizada
const generateDisplayReference = (product) => {
  if (!product.id) {
    return `BE-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
  }
  const idStr = product.id.toString();
  const numericPart = idStr.slice(-4).padStart(4, '0');
  return `BE-${numericPart}`;
};

export default function FeaturedProductsHome({ products, isLoading, onViewDetails }) {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center justify-center gap-2 mb-4"
          >
            <TrendingUp className="h-6 w-6 text-primary" />
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal">
              Mais Visualizados
            </h2>
          </motion.div>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-gray-600 text-lg max-w-2xl mx-auto"
          >
            Produtos que estão chamando atenção e fazendo sucesso entre nossos clientes
          </motion.p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 mb-12">
          {isLoading ? (
            Array(10).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-xl animate-pulse">
                <div className="aspect-square bg-gray-200 rounded-t-xl"></div>
                <div className="p-4">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                </div>
              </div>
            ))
          ) : (
            products.slice(0, 10).map((product, index) => {
              const displayReference = generateDisplayReference(product);
              return (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  className="group bg-white rounded-xl shadow-sm hover:shadow-lg transition-all overflow-hidden cursor-pointer"
                  onClick={() => onViewDetails(product)}
                >
                  <div className="relative aspect-square overflow-hidden bg-white p-2">
                    <img
                      src={getProductImageUrl(product.MainImage || product.image_url)}
                      alt={product.Name || product.name}
                      className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                      onError={(e) => { 
                        e.currentTarget.src = 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60'; 
                      }}
                    />
                  </div>
                  <div className="p-3">
                    <h3 className="font-semibold text-xs text-charcoal line-clamp-2 group-hover:text-primary min-h-[32px]">
                      {product.Name || product.name}
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">
                      Ref: {displayReference}
                    </p>
                    {product.Brand && (
                      <p className="text-xs text-primary mt-1 font-medium">
                        {product.Brand}
                      </p>
                    )}
                  </div>
                </motion.div>
              );
            })
          )}
        </div>

        <div className="text-center">
          <Link to={createPageUrl("Products")}>
            <Button size="lg" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white">
              Ver Catálogo Completo
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
