import React from "react";
import { motion } from "framer-motion";

export default function ProcessSection() {
  const steps = [
    {
      title: "Ideação",
      description: "Entendemos profundamente suas necessidades, pesquisamos e alinhamos objetivos para criar soluções únicas.",
      color: "bg-blue-500",
      number: "1"
    },
    {
      title: "Design",
      description: "Desenvolvemos protótipos e designs que capturam a essência da sua marca e impressionam visualmente.",
      color: "bg-pink-500",
      number: "2"
    },
    {
      title: "Produção",
      description: "Utilizamos as melhores técnicas de personalização e controle de qualidade para garantir a excelência.",
      color: "bg-green-500",
      number: "3"
    },
    {
      title: "Entrega",
      description: "Finalizamos com uma embalagem especial que transforma o presente em uma experiência memorável.",
      color: "bg-pink-600",
      number: "4"
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4"
          >
            Nosso Processo Criativo
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-gray-600 text-base max-w-2xl mx-auto"
          >
            Cada projeto é realizado de um processo cuidadoso que combina criatividade, tecnologia e atenção aos detalhes para criar experiências inesquecíveis.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {/* Connection Line */}
          <div className="hidden lg:block absolute top-16 left-[12.5%] right-[12.5%] h-1 bg-gradient-to-r from-blue-500 via-pink-500 via-green-500 to-pink-600 opacity-20"></div>
          
          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="relative text-center"
            >
              <div className={`w-32 h-32 ${step.color} rounded-full flex items-center justify-center mx-auto mb-6 relative z-10`}>
                <span className="text-white text-4xl font-bold">{step.number}</span>
              </div>
              
              <h3 className="font-serif text-xl font-bold text-charcoal mb-3">
                {step.title}
              </h3>
              
              <p className="text-gray-600 text-sm leading-relaxed">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Stats Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mt-20 bg-white rounded-2xl shadow-sm p-12 text-center"
        >
          <h3 className="font-serif text-2xl font-bold text-charcoal mb-6">
            Da conceito à realidade em tempo recorde
          </h3>
          <p className="text-gray-600 mb-12 max-w-3xl mx-auto">
            Nossa equipe experiente trabalha de forma integrada para garantir agilidade sem comprometer a qualidade e atenção aos detalhes necessárias.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="text-4xl font-bold text-primary mb-2">7-15</div>
              <div className="text-sm text-gray-600">Dias de produção</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">98%</div>
              <div className="text-sm text-gray-600">Taxa de satisfação</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-sm text-gray-600">Projetos realizados</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}