import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const defaultSlides = [
  {
    image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    title: "Transforme Momentos em Memórias Inesquecíveis",
    subtitle: "Criamos brindes personalizados que encantam, surpreendem e fortalecem os laços entre sua marca e quem mais importa"
  },
  {
    image: "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    title: "Presentes Corporativos que Impressionam",
    subtitle: "Do kit de boas-vindas ao presente executivo: soluções criativas para cada ocasião especial da sua empresa"
  },
  {
    image: "https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    title: "Sustentabilidade com Estilo e Propósito",
    subtitle: "Brindes eco-friendly que comunicam os valores da sua marca e fazem a diferença para o planeta"
  },
  {
    image: "https://images.unsplash.com/photo-1556740714-a8395b3bf30f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80",
    title: "Personalização é Nossa Especialidade",
    subtitle: "Laser, bordado, silk screen, transfer: técnicas premium para criar produtos únicos que contam a sua história"
  }
];

export default function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [heroSlides, setHeroSlides] = useState(defaultSlides);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadHeroSlides();
  }, []);

  const loadHeroSlides = async () => {
    try {
      const slides = await base44.entities.HeroBanner.filter({ active: true }, 'order');
      if (slides.length > 0) {
        const formattedSlides = slides.map(slide => ({
          image: slide.image_url,
          title: slide.title,
          subtitle: slide.subtitle
        }));
        setHeroSlides(formattedSlides);
      }
    } catch (error) {
      console.error('Erro ao carregar slides do hero:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [heroSlides.length]);

  if (isLoading) {
    return (
      <section className="relative h-[90vh] flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
      {/* Background Slideshow */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0"
        >
          <img
            src={heroSlides[currentSlide].image}
            alt="Hero background"
            className="w-full h-full object-cover"
          />
          {/* Pink Overlay */}
          <div className="absolute inset-0 bg-primary/70"></div>
        </motion.div>
      </AnimatePresence>

      {/* Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              {heroSlides[currentSlide].title}
            </h1>
            <p className="text-lg md:text-xl mb-8 leading-relaxed text-white/90">
              {heroSlides[currentSlide].subtitle}
            </p>
          </motion.div>
        </AnimatePresence>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to={createPageUrl("Portfolio")}>
            <Button 
              size="lg" 
              className="bg-white text-primary hover:bg-white/95 hover:shadow-xl font-semibold px-8 rounded-full shadow-lg transition-all duration-300 border-2 border-white"
            >
              Veja Nossos Trabalhos
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
          <Link to={createPageUrl("Contact")}>
            <Button 
              size="lg" 
              className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30 font-semibold px-8 rounded-full border-2 border-white shadow-lg transition-all duration-300"
            >
              Peça um Orçamento
            </Button>
          </Link>
        </div>

        {/* Slide Indicators */}
        <div className="flex justify-center gap-2 mt-12">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`h-3 rounded-full transition-all duration-300 ${
                index === currentSlide 
                  ? 'bg-white w-8 shadow-md' 
                  : 'bg-white/50 w-3 hover:bg-white/70'
              }`}
              aria-label={`Ir para slide ${index + 1}`}
            />
          ))}
        </div>
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={() => setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length)}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/30 backdrop-blur-sm hover:bg-white/40 text-white p-3 rounded-full transition-all duration-300 border border-white/50 shadow-lg"
        aria-label="Slide anterior"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
        </svg>
      </button>
      <button
        onClick={() => setCurrentSlide((prev) => (prev + 1) % heroSlides.length)}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/30 backdrop-blur-sm hover:bg-white/40 text-white p-3 rounded-full transition-all duration-300 border border-white/50 shadow-lg"
        aria-label="Próximo slide"
      >
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </button>
    </section>
  );
}