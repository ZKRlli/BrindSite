import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function FeaturedProjects({ projects, isLoading }) {
  const categoryLabels = {
    corporativo: "Corporativo",
    casamento: "Casamento",
    festa: "Festas",
    aniversario: "Aniversário",
    outros: "Outros"
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4"
          >
            Projetos em Destaque
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-gray-600 text-base max-w-2xl mx-auto"
          >
            Descubra alguns dos nossos trabalhos mais marcantes, onde cada presente conta uma história viva e fortalece conexões especiais.
          </motion.p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="bg-white rounded-lg animate-pulse border">
                <div className="aspect-[4/3] bg-gray-200 rounded-t-lg mb-4"></div>
                <div className="p-6">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group bg-white rounded-lg shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden border border-gray-100"
              >
                <div className="relative aspect-[4/3] overflow-hidden bg-gray-100">
                  <img
                    src={project.main_image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    onError={(e) => {
                      e.currentTarget.src = 'https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';
                    }}
                  />
                  <Badge className="absolute top-4 left-4 bg-primary text-white border-0 uppercase text-xs font-semibold">
                    {categoryLabels[project.category]}
                  </Badge>
                </div>
                
                <div className="p-6">
                  <span className="text-xs text-primary font-medium uppercase tracking-wide">
                    {categoryLabels[project.category]}
                  </span>
                  <h3 className="font-serif font-bold text-lg text-charcoal mt-2 mb-3 group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-sm text-gray-600 mb-4 line-clamp-2 leading-relaxed">
                    {project.description}
                  </p>
                  <div className="flex items-center text-primary text-sm font-medium">
                    Ler mais →
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        <div className="text-center">
          <Link to={createPageUrl("Portfolio")}>
            <Button size="lg" className="bg-gradient-pink-purple hover:opacity-90 text-white font-medium px-8 rounded-full">
              Ver Todos os Artigos →
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}