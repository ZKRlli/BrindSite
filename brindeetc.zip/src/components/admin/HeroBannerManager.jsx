import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { 
  Plus, Upload, Loader2, CheckCircle, AlertCircle, 
  Edit, Trash2, Image as ImageIcon, ArrowUp, ArrowDown
} from 'lucide-react';

export default function HeroBannerManager() {
  const [slides, setSlides] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState({ message: '', type: '' });
  
  const [slideForm, setSlideForm] = useState({
    title: '',
    subtitle: '',
    image_url: '',
    order: 0,
    active: true
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageFile, setImageFile] = useState(null);
  const [editingSlide, setEditingSlide] = useState(null);

  useEffect(() => {
    loadSlides();
  }, []);

  const loadSlides = async () => {
    setIsLoading(true);
    try {
      const fetchedSlides = await base44.entities.HeroBanner.list('order', 50);
      setSlides(fetchedSlides);
    } catch (error) {
      console.error('Erro ao carregar slides:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSlideSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let imageUrl = slideForm.image_url;
      
      if (imageFile) {
        const uploadResult = await base44.integrations.Core.UploadFile({ file: imageFile });
        imageUrl = uploadResult.file_url;
      }

      const slideData = {
        ...slideForm,
        image_url: imageUrl
      };

      if (editingSlide) {
        await base44.entities.HeroBanner.update(editingSlide.id, slideData);
        setUploadStatus({ message: 'Slide atualizado com sucesso!', type: 'success' });
      } else {
        await base44.entities.HeroBanner.create(slideData);
        setUploadStatus({ message: 'Slide adicionado com sucesso!', type: 'success' });
      }
      
      setSlideForm({
        title: '', subtitle: '', image_url: '', order: 0, active: true
      });
      setImageFile(null);
      setEditingSlide(null);
      loadSlides();
    } catch (error) {
      console.error('Erro ao salvar slide:', error);
      setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEdit = (slide) => {
    setEditingSlide(slide);
    setSlideForm({
      title: slide.title,
      subtitle: slide.subtitle,
      image_url: slide.image_url,
      order: slide.order,
      active: slide.active
    });
  };

  const handleDelete = async (slideId) => {
    if (!confirm('Tem certeza que deseja excluir este slide?')) return;
    
    try {
      await base44.entities.HeroBanner.delete(slideId);
      setUploadStatus({ message: 'Slide excluído com sucesso!', type: 'success' });
      loadSlides();
    } catch (error) {
      console.error('Erro ao excluir slide:', error);
      setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
    }
  };

  const handleToggleActive = async (slide) => {
    try {
      await base44.entities.HeroBanner.update(slide.id, { active: !slide.active });
      loadSlides();
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
    }
  };

  const handleReorder = async (slide, direction) => {
    const newOrder = direction === 'up' ? slide.order - 1 : slide.order + 1;
    try {
      await base44.entities.HeroBanner.update(slide.id, { order: newOrder });
      loadSlides();
    } catch (error) {
      console.error('Erro ao reordenar:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-charcoal">Gerenciar Banner Hero</h2>
        <Button onClick={loadSlides} variant="outline">
          Atualizar Lista
        </Button>
      </div>

      <Tabs defaultValue="add" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="add">{editingSlide ? 'Editar Slide' : 'Adicionar Slide'}</TabsTrigger>
          <TabsTrigger value="list">Lista de Slides ({slides.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="mr-2 h-5 w-5" />
                {editingSlide ? 'Editar Slide do Banner' : 'Novo Slide do Banner'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSlideSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="title">Título *</Label>
                  <Input
                    id="title"
                    value={slideForm.title}
                    onChange={(e) => setSlideForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Ex: Experiências Corporativas Memoráveis"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="subtitle">Subtítulo *</Label>
                  <Textarea
                    id="subtitle"
                    value={slideForm.subtitle}
                    onChange={(e) => setSlideForm(prev => ({ ...prev, subtitle: e.target.value }))}
                    placeholder="Ex: Fortalecemos relacionamentos empresariais com presentes que impressionam"
                    rows={3}
                    required
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="image_url">URL da Imagem</Label>
                    <Input
                      id="image_url"
                      type="url"
                      value={slideForm.image_url}
                      onChange={(e) => setSlideForm(prev => ({ ...prev, image_url: e.target.value }))}
                      placeholder="https://..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="image_file">Ou Faça Upload da Imagem</Label>
                    <Input
                      id="image_file"
                      type="file"
                      accept="image/*"
                      onChange={(e) => setImageFile(e.target.files[0])}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="order">Ordem de Exibição</Label>
                    <Input
                      id="order"
                      type="number"
                      value={slideForm.order}
                      onChange={(e) => setSlideForm(prev => ({ ...prev, order: parseInt(e.target.value) }))}
                    />
                  </div>
                  <div className="flex items-center space-x-2 pt-8">
                    <Switch
                      id="active"
                      checked={slideForm.active}
                      onCheckedChange={(checked) => setSlideForm(prev => ({ ...prev, active: checked }))}
                    />
                    <Label htmlFor="active">Slide Ativo</Label>
                  </div>
                </div>

                <div className="flex gap-3">
                  {editingSlide && (
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setEditingSlide(null);
                        setSlideForm({
                          title: '', subtitle: '', image_url: '', order: 0, active: true
                        });
                      }}
                    >
                      Cancelar
                    </Button>
                  )}
                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 bg-primary hover:bg-primary/90"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        {editingSlide ? 'Atualizando...' : 'Adicionando...'}
                      </>
                    ) : (
                      <>
                        <Plus className="mr-2 h-4 w-4" />
                        {editingSlide ? 'Atualizar Slide' : 'Adicionar Slide'}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Slides do Banner ({slides.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>Carregando slides...</p>
                </div>
              ) : slides.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <ImageIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Nenhum slide cadastrado ainda.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {slides.map((slide, index) => (
                    <div key={slide.id} className="border rounded-lg p-4 flex gap-4">
                      <img 
                        src={slide.image_url} 
                        alt={slide.title}
                        className="w-32 h-24 object-cover bg-gray-50 rounded flex-shrink-0"
                        onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'; }}
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-base">{slide.title}</h3>
                            <p className="text-sm text-gray-600 mt-1">{slide.subtitle}</p>
                          </div>
                          <div className="flex gap-2">
                            <Badge variant={slide.active ? "default" : "secondary"}>
                              {slide.active ? 'Ativo' : 'Inativo'}
                            </Badge>
                            <Badge variant="outline">Ordem: {slide.order}</Badge>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleReorder(slide, 'up')}
                            disabled={index === 0}
                          >
                            <ArrowUp className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleReorder(slide, 'down')}
                            disabled={index === slides.length - 1}
                          >
                            <ArrowDown className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleToggleActive(slide)}
                          >
                            {slide.active ? 'Desativar' : 'Ativar'}
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(slide)}
                          >
                            <Edit className="h-4 w-4 mr-1" />
                            Editar
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDelete(slide.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {uploadStatus.message && (
        <div className={`flex items-center p-4 rounded-md text-sm ${
          uploadStatus.type === 'success' ? 'bg-green-100 text-green-800' :
          uploadStatus.type === 'error' ? 'bg-red-100 text-red-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {uploadStatus.type === 'success' && <CheckCircle className="mr-2 h-4 w-4" />}
          {uploadStatus.type === 'error' && <AlertCircle className="mr-2 h-4 w-4" />}
          {uploadStatus.message}
        </div>
      )}
    </div>
  );
}