
import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Plus, Upload, Loader2, CheckCircle, AlertCircle, 
  Download, FileUp, Trash2, Image as ImageIcon
} from 'lucide-react';

const SPOTGIFTS_IMAGE_BASE = 'https://www.spotgifts.com.br/fotos/produtos/';

export default function ProductManager() {
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState({ message: '', type: '' });
  const [uploadProgress, setUploadProgress] = useState(0);
  const [csvFile, setCsvFile] = useState(null);
  const [isMigratingImages, setIsMigratingImages] = useState(false);
  
  // Individual product form
  const [productForm, setProductForm] = useState({
    ProdReference: '',
    Name: '',
    Description: '',
    Type: '',
    SubType: '',
    Brand: '',
    CountryOfOrigin: '',
    MainImage: '',
    AvailableGross: 0,
    Materials: '',
    WeightGr: 0
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageReference, setImageReference] = useState('');

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    setIsLoading(true);
    try {
      const fetchedProducts = await base44.entities.Product.list('-created_date', 100);
      setProducts(fetchedProducts);
    } catch (error) {
      console.error('Erro ao carregar produtos:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Função para baixar imagem da Spotgifts e fazer upload para Base44
  const downloadAndUploadImage = async (imageRef) => {
    try {
      // Construir URL completa
      const imageUrl = imageRef.startsWith('http') 
        ? imageRef 
        : `${SPOTGIFTS_IMAGE_BASE}${imageRef}`;
      
      // Fazer fetch da imagem
      const response = await fetch(imageUrl);
      if (!response.ok) throw new Error(`Erro ao baixar imagem: ${response.statusText}`);
      
      const blob = await response.blob();
      const file = new File([blob], `product-${Date.now()}-${imageRef.split('/').pop()}.jpg`, { type: 'image/jpeg' });
      
      // Upload para Base44
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      
      return file_url;
    } catch (error) {
      console.error('Erro ao processar imagem:', error);
      throw error;
    }
  };

  const handleProductSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let finalImageUrl = productForm.MainImage;
      
      // Se tiver referência de imagem, baixar e fazer upload
      if (imageReference) {
        setUploadStatus({ message: 'Processando imagem...', type: 'info' });
        finalImageUrl = await downloadAndUploadImage(imageReference);
      }

      const productData = {
        ...productForm,
        MainImage: finalImageUrl
      };

      await base44.entities.Product.create(productData);
      
      setProductForm({
        ProdReference: '', Name: '', Description: '', Type: '', SubType: '',
        Brand: '', CountryOfOrigin: '', MainImage: '', AvailableGross: 0,
        Materials: '', WeightGr: 0
      });
      setImageReference('');
      setUploadStatus({ message: 'Produto cadastrado com sucesso!', type: 'success' });
      loadProducts();
    } catch (error) {
      console.error('Erro ao cadastrar produto:', error);
      setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCsvUpload = async () => {
    if (!csvFile) {
      setUploadStatus({ message: 'Por favor, selecione um arquivo.', type: 'error' });
      return;
    }

    setIsLoading(true);
    setUploadProgress(0);
    setUploadStatus({ message: 'Processando arquivo CSV...', type: 'info' });

    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target.result;
      try {
        const productsData = parseCSV(text);

        if (productsData.length === 0) {
          throw new Error('Nenhum produto válido encontrado no arquivo.');
        }

        setUploadStatus({ message: `Processando ${productsData.length} produtos e suas imagens...`, type: 'info' });

        // Processar produtos um por um para fazer upload das imagens
        const processedProducts = [];
        for (let i = 0; i < productsData.length; i++) {
          const product = productsData[i];
          
          try {
            // Se tiver MainImage e não for uma URL completa do base44, baixar e fazer upload
            if (product.MainImage && !product.MainImage.includes('supabase.co')) {
              const newImageUrl = await downloadAndUploadImage(product.MainImage);
              product.MainImage = newImageUrl;
            }
            
            processedProducts.push(product);
            setUploadProgress(Math.round(((i + 1) / productsData.length) * 100));
          } catch (error) {
            console.error(`Erro ao processar produto ${product.ProdReference}:`, error);
            // Continuar com os outros produtos mesmo se um falhar
          }
        }

        // Criar todos os produtos de uma vez
        if (processedProducts.length > 0) {
          await base44.entities.Product.bulkCreate(processedProducts);
          setUploadStatus({ 
            message: `${processedProducts.length} produtos importados com sucesso! As imagens foram transferidas para o storage seguro.`, 
            type: 'success' 
          });
        } else {
          throw new Error('Nenhum produto foi processado com sucesso.');
        }
        
        setCsvFile(null);
        setUploadProgress(0);
        loadProducts();
      } catch (error) {
        console.error('Erro ao processar o arquivo:', error);
        setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsText(csvFile);
  };

  const parseCSV = (csvText) => {
    const lines = csvText.split(/\r?\n/).filter(line => line.trim());
    if (lines.length < 2) return [];
    
    const header = lines[0].split(',').map(h => h.trim());
    const rows = lines.slice(1).map(line => {
      const values = line.split(',').map(v => v.trim());
      if (values.length !== header.length) return null;
      
      let obj = {};
      header.forEach((key, i) => {
        const value = values[i];
        
        // Converter tipos apropriadamente
        if (['AvailableGross', 'WeightGr', 'BoxQuantity', 'Weight'].includes(key)) {
          obj[key] = parseFloat(value) || 0;
        } else if (['IsTextil', 'HasColors', 'HasSizes', 'PvcFree', 'IsSeasonal', 'IsStockOut'].includes(key)) {
          obj[key] = value.toLowerCase() === 'true';
        } else if (['AditionalImageList', 'AllImageList', 'Sizes', 'Capacitys', 'KeyWords'].includes(key)) {
          obj[key] = value ? value.split(';').map(v => v.trim()) : [];
        } else {
          obj[key] = value;
        }
      });
      return obj;
    }).filter(Boolean);
    
    return rows;
  };

  const handleDeleteProduct = async (productId) => {
    if (!confirm('Tem certeza que deseja deletar este produto?')) return;
    
    try {
      await base44.entities.Product.delete(productId);
      setUploadStatus({ message: 'Produto deletado com sucesso!', type: 'success' });
      loadProducts();
    } catch (error) {
      console.error('Erro ao deletar produto:', error);
      setUploadStatus({ message: `Erro ao deletar: ${error.message}`, type: 'error' });
    }
  };

  const loadSampleProducts = async () => {
    setIsLoading(true);
    setUploadStatus({ message: 'Carregando produtos de exemplo...', type: 'info' });
    
    try {
      const sampleProducts = [
        { ProdReference: "92387", Name: "Mochila EDINBURGH BPACK", Type: "Mochilas e Malas", SubType: "Mochilas Notebook", Brand: "Midocean", Description: "Mochila estilo militar em poliéster reciclado 600D", MainImage: "92387.jpg", AvailableGross: 150, CountryOfOrigin: "China", Materials: "Poliéster 600D Reciclado", WeightGr: 580 },
        { ProdReference: "97193", Name: "Fones COBAIN Wireless", Type: "Tecnologia", SubType: "Áudio", Brand: "Midocean", Description: "Fones wireless em ABS reciclado e bambu", MainImage: "97193.jpg", AvailableGross: 200, CountryOfOrigin: "China", Materials: "ABS Reciclado, Bambu", WeightGr: 165 },
        { ProdReference: "94378", Name: "Squeeze KARSTEN 560ml", Type: "Squeezes e Copos", SubType: "Garrafas", Brand: "Midocean", Description: "Squeeze em aço inoxidável", MainImage: "94378.jpg", AvailableGross: 300, CountryOfOrigin: "China", Materials: "Aço Inoxidável", WeightGr: 140 }
      ];

      // Processar e fazer upload das imagens
      const processedProducts = [];
      for (const product of sampleProducts) {
        try {
          const newImageUrl = await downloadAndUploadImage(product.MainImage);
          processedProducts.push({ ...product, MainImage: newImageUrl });
        } catch (error) {
          console.error(`Erro ao processar ${product.ProdReference}:`, error);
          setUploadStatus({ message: `Erro ao processar imagem para ${product.Name}: ${error.message}`, type: 'error' });
        }
      }

      if (processedProducts.length > 0) {
        await base44.entities.Product.bulkCreate(processedProducts);
        setUploadStatus({ message: `${processedProducts.length} produtos de exemplo importados!`, type: 'success' });
        loadProducts();
      } else {
        setUploadStatus({ message: 'Nenhum produto de exemplo foi processado com sucesso.', type: 'error' });
      }
    } catch (error) {
      console.error('Erro ao carregar exemplos:', error);
      setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
    } finally {
      setIsLoading(false);
    }
  };

  // Função para migrar imagens de produtos existentes
  const migrateExistingImages = async () => {
    setIsMigratingImages(true);
    setUploadStatus({ message: 'Verificando produtos com imagens não migradas...', type: 'info' });
    setUploadProgress(0);
    
    try {
      const allProducts = await base44.entities.Product.list('-created_date', 2000); // Fetch a reasonable number of products
      
      // Filter products that have a MainImage that looks like a filename (not a full URL or supabase URL)
      const productsToMigrate = allProducts.filter(p => 
        p.MainImage && 
        !p.MainImage.includes('supabase.co') && 
        !p.MainImage.startsWith('http')
      );
      
      if (productsToMigrate.length === 0) {
        setUploadStatus({ 
          message: 'Todas as imagens já estão migradas ou não há produtos com imagens para migrar.', 
          type: 'success' 
        });
        setIsMigratingImages(false);
        return;
      }
      
      setUploadStatus({ 
        message: `Migrando ${productsToMigrate.length} imagens para o storage seguro...`, 
        type: 'info' 
      });
      
      let migratedCount = 0;
      const failedProducts = [];
      
      for (let i = 0; i < productsToMigrate.length; i++) {
        const product = productsToMigrate[i];
        
        try {
          const newImageUrl = await downloadAndUploadImage(product.MainImage);
          await base44.entities.Product.update(product.id, { MainImage: newImageUrl });
          migratedCount++;
          setUploadProgress(Math.round(((i + 1) / productsToMigrate.length) * 100));
        } catch (error) {
          console.error(`Erro ao migrar imagem do produto ${product.ProdReference}:`, error);
          failedProducts.push(product.ProdReference);
          setUploadStatus({ message: `Erro ao migrar imagem para ${product.ProdReference}: ${error.message}`, type: 'error' });
          // Optionally, wait a bit or retry, but for now, just log and continue
        }
      }
      
      if (failedProducts.length > 0) {
        setUploadStatus({ 
          message: `${migratedCount} imagens migradas com sucesso. ${failedProducts.length} falharam: ${failedProducts.join(', ')}. Verifique o console para detalhes.`, 
          type: 'success' // Still success-ish, but with failures
        });
      } else {
        setUploadStatus({ 
          message: `${migratedCount} imagens migradas com sucesso! Todas as imagens agora estão protegidas.`, 
          type: 'success' 
        });
      }
      
      setUploadProgress(0);
      loadProducts();
    } catch (error) {
      console.error('Erro geral na migração de imagens:', error);
      setUploadStatus({ message: `Erro geral na migração de imagens: ${error.message}`, type: 'error' });
    } finally {
      setIsMigratingImages(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-charcoal">Gerenciar Produtos</h2>
        <div className="flex gap-2">
          <Button onClick={migrateExistingImages} variant="outline" disabled={isMigratingImages}>
            {isMigratingImages ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Migrando...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Migrar Imagens
              </>
            )}
          </Button>
          <Button onClick={loadProducts} variant="outline">
            Atualizar Lista
          </Button>
        </div>
      </div>

      {/* Alert sobre migração */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h4 className="font-semibold text-yellow-900 mb-2 flex items-center">
          <AlertCircle className="mr-2 h-4 w-4" />
          Proteção de Imagens
        </h4>
        <p className="text-sm text-yellow-800 mb-3">
          Se você importou produtos e as imagens não aparecem, ou para garantir que todas as imagens estejam seguras e anonimizadas, 
          clique em "Migrar Imagens" para transferir todas as imagens para o storage seguro.
          Isso garante que seus clientes não vejam a origem das imagens.
        </p>
        <p className="text-xs text-yellow-700">
          O sistema detecta automaticamente produtos com imagens não migradas (apenas nome de arquivo ou URLs externas diretas) 
          e faz o download + upload para o storage protegido.
        </p>
        {isMigratingImages && uploadProgress > 0 && (
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-sm text-yellow-800">
              <span>Progresso da Migração</span>
              <span>{uploadProgress}%</span>
            </div>
            <Progress value={uploadProgress} className="h-2 bg-yellow-300" />
          </div>
        )}
      </div>

      <Tabs defaultValue="individual" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="individual">Cadastro Individual</TabsTrigger>
          <TabsTrigger value="bulk">Upload CSV</TabsTrigger>
          <TabsTrigger value="sample">Exemplos</TabsTrigger>
          <TabsTrigger value="list">Lista ({products.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="individual">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="mr-2 h-5 w-5" />
                Novo Produto
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProductSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="ProdReference">Referência do Produto *</Label>
                    <Input
                      id="ProdReference"
                      value={productForm.ProdReference}
                      onChange={(e) => setProductForm(prev => ({ ...prev, ProdReference: e.target.value }))}
                      placeholder="Ex: 92387"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="Name">Nome do Produto *</Label>
                    <Input
                      id="Name"
                      value={productForm.Name}
                      onChange={(e) => setProductForm(prev => ({ ...prev, Name: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="Description">Descrição</Label>
                  <Textarea
                    id="Description"
                    value={productForm.Description}
                    onChange={(e) => setProductForm(prev => ({ ...prev, Description: e.target.value }))}
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="Type">Tipo</Label>
                    <Input
                      id="Type"
                      value={productForm.Type}
                      onChange={(e) => setProductForm(prev => ({ ...prev, Type: e.target.value }))}
                      placeholder="Ex: Mochilas e Malas"
                    />
                  </div>
                  <div>
                    <Label htmlFor="SubType">Subtipo</Label>
                    <Input
                      id="SubType"
                      value={productForm.SubType}
                      onChange={(e) => setProductForm(prev => ({ ...prev, SubType: e.target.value }))}
                      placeholder="Ex: Mochilas Notebook"
                    />
                  </div>
                  <div>
                    <Label htmlFor="Brand">Marca</Label>
                    <Input
                      id="Brand"
                      value={productForm.Brand}
                      onChange={(e) => setProductForm(prev => ({ ...prev, Brand: e.target.value }))}
                      placeholder="Ex: Midocean"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="CountryOfOrigin">País de Origem</Label>
                    <Input
                      id="CountryOfOrigin"
                      value={productForm.CountryOfOrigin}
                      onChange={(e) => setProductForm(prev => ({ ...prev, CountryOfOrigin: e.target.value }))}
                      placeholder="Ex: China"
                    />
                  </div>
                  <div>
                    <Label htmlFor="AvailableGross">Estoque Disponível</Label>
                    <Input
                      id="AvailableGross"
                      type="number"
                      value={productForm.AvailableGross}
                      onChange={(e) => setProductForm(prev => ({ ...prev, AvailableGross: parseInt(e.target.value) || 0 }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="WeightGr">Peso (gramas)</Label>
                    <Input
                      id="WeightGr"
                      type="number"
                      value={productForm.WeightGr}
                      onChange={(e) => setProductForm(prev => ({ ...prev, WeightGr: parseFloat(e.target.value) || 0 }))}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="Materials">Materiais</Label>
                  <Input
                    id="Materials"
                    value={productForm.Materials}
                    onChange={(e) => setProductForm(prev => ({ ...prev, Materials: e.target.value }))}
                    placeholder="Ex: Poliéster 600D Reciclado"
                  />
                </div>

                <div className="border-t pt-4">
                  <h3 className="font-semibold mb-3 flex items-center">
                    <ImageIcon className="mr-2 h-4 w-4" />
                    Imagem do Produto
                  </h3>
                  <div className="space-y-2">
                    <Label htmlFor="imageReference">
                      Código/Nome da Imagem (sem revelar origem) *
                    </Label>
                    <Input
                      id="imageReference"
                      value={imageReference}
                      onChange={(e) => setImageReference(e.target.value)}
                      placeholder="Ex: 92387.jpg ou apenas 92387"
                      required
                    />
                    <p className="text-xs text-gray-500">
                      A imagem será baixada automaticamente e armazenada no nosso servidor. Seus clientes não verão a origem.
                    </p>
                  </div>
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processando...
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Cadastrar Produto
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="mr-2 h-5 w-5" />
                Importação em Massa via CSV
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h4 className="font-semibold text-blue-900 mb-2">ℹ️ Sistema de Proteção de Imagens</h4>
                <p className="text-sm text-blue-800">
                  As imagens serão automaticamente baixadas e transferidas para nosso servidor seguro. 
                  Seus clientes não terão acesso à URL original das imagens.
                </p>
              </div>

              <div>
                <Label htmlFor="csv-file">Arquivo CSV</Label>
                <Input
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => setCsvFile(e.target.files[0])}
                />
                <p className="text-xs text-gray-500 mt-2">
                  <strong>Colunas obrigatórias:</strong> ProdReference, Name, MainImage<br />
                  <strong>Coluna MainImage:</strong> Pode ser apenas o nome do arquivo (ex: 92387.jpg) - o sistema buscará automaticamente
                </p>
              </div>

              {uploadProgress > 0 && uploadProgress < 100 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Processando imagens...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              )}

              <Button 
                onClick={handleCsvUpload} 
                disabled={isLoading || !csvFile}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processando e Transferindo Imagens...
                  </>
                ) : (
                  <>
                    <FileUp className="mr-2 h-4 w-4" />
                    Importar Produtos
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sample">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Download className="mr-2 h-5 w-5" />
                Produtos de Exemplo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600">
                Importe 3 produtos de exemplo para testar o sistema. As imagens serão 
                automaticamente baixadas e armazenadas de forma segura.
              </p>

              <Button 
                onClick={loadSampleProducts} 
                disabled={isLoading}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Importando Exemplos...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Importar Produtos de Exemplo
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Produtos Cadastrados ({products.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>Carregando produtos...</p>
                </div>
              ) : products.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <ImageIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                  <p>Nenhum produto cadastrado ainda.</p>
                  <p className="text-sm mt-2">Use as abas acima para adicionar produtos.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {products.map(product => (
                    <div key={product.id} className="border rounded-lg p-4 space-y-2 hover:shadow-md transition-shadow">
                      <img 
                        src={product.MainImage} 
                        alt={product.Name}
                        className="w-full h-32 object-contain bg-gray-50 rounded"
                        onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1588949869355-32939b45a498?w=400'; }}
                      />
                      <div className="space-y-1">
                        <h3 className="font-semibold text-sm truncate">{product.Name}</h3>
                        <p className="text-xs text-gray-500">Ref: {product.ProdReference}</p>
                        <div className="flex flex-wrap gap-1">
                          {product.Brand && (
                            <Badge variant="outline" className="text-xs">{product.Brand}</Badge>
                          )}
                          {product.Type && (
                            <Badge variant="outline" className="text-xs">{product.Type}</Badge>
                          )}
                        </div>
                        <p className="text-xs text-green-600">
                          Estoque: {product.AvailableGross || 0} un
                        </p>
                        <Button
                          onClick={() => handleDeleteProduct(product.id)}
                          variant="destructive"
                          size="sm"
                          className="w-full mt-2"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Deletar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {uploadStatus.message && (
        <div className={`flex items-center p-4 rounded-md text-sm ${
          uploadStatus.type === 'success' ? 'bg-green-100 text-green-800' :
          uploadStatus.type === 'error' ? 'bg-red-100 text-red-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {uploadStatus.type === 'success' && <CheckCircle className="mr-2 h-4 w-4" />}
          {uploadStatus.type === 'error' && <AlertCircle className="mr-2 h-4 w-4" />}
          {uploadStatus.type === 'info' && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {uploadStatus.message}
        </div>
      )}
    </div>
  );
}
