import React, { useState, useEffect } from 'react';
import { Project } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  Plus, Upload, Loader2, CheckCircle, AlertCircle, 
  Star, Image as ImageIcon, FileUp
} from 'lucide-react';

const projectCategories = ['corporativo', 'casamento', 'festa', 'aniversario', 'outros'];

export default function ProjectManager() {
  const [projects, setProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState({ message: '', type: '' });
  const [csvFile, setCsvFile] = useState(null);
  
  // Individual project form
  const [projectForm, setProjectForm] = useState({
    title: '',
    client: '',
    category: '',
    description: '',
    challenge: '',
    solution: '',
    materials: '',
    main_image: '',
    gallery_images: [],
    featured: false,
    year: new Date().getFullYear()
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [mainImageFile, setMainImageFile] = useState(null);
  const [galleryFiles, setGalleryFiles] = useState([]);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = async () => {
    setIsLoading(true);
    try {
      const fetchedProjects = await Project.list('-created_date', 50);
      setProjects(fetchedProjects);
    } catch (error) {
      console.error('Erro ao carregar projetos:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleProjectSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      let mainImageUrl = projectForm.main_image;
      let galleryUrls = [...projectForm.gallery_images];
      
      // Upload main image if file selected
      if (mainImageFile) {
        const uploadResult = await UploadFile({ file: mainImageFile });
        mainImageUrl = uploadResult.file_url;
      }

      // Upload gallery images
      if (galleryFiles.length > 0) {
        const galleryUploads = await Promise.all(
          Array.from(galleryFiles).map(file => UploadFile({ file }))
        );
        galleryUrls = [...galleryUrls, ...galleryUploads.map(result => result.file_url)];
      }

      const projectData = {
        ...projectForm,
        main_image: mainImageUrl,
        gallery_images: galleryUrls
      };

      await Project.create(projectData);
      
      setProjectForm({
        title: '', client: '', category: '', description: '',
        challenge: '', solution: '', materials: '', main_image: '',
        gallery_images: [], featured: false, year: new Date().getFullYear()
      });
      setMainImageFile(null);
      setGalleryFiles([]);
      setUploadStatus({ message: 'Projeto cadastrado com sucesso!', type: 'success' });
      loadProjects();
    } catch (error) {
      console.error('Erro ao cadastrar projeto:', error);
      setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCsvUpload = async () => {
    if (!csvFile) {
      setUploadStatus({ message: 'Por favor, selecione um arquivo.', type: 'error' });
      return;
    }

    setIsLoading(true);
    setUploadStatus({ message: 'Processando arquivo...', type: 'info' });

    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target.result;
      try {
        const projectsToCreate = parseCSV(text);

        if (projectsToCreate.length === 0) {
          throw new Error('Nenhum projeto válido encontrado no arquivo.');
        }

        const missingFields = projectsToCreate.some(p => 
          !p.title || !p.client || !p.category || !p.description || !p.main_image
        );
        if (missingFields) {
          throw new Error('Todos os projetos devem ter "title", "client", "category", "description" e "main_image".');
        }

        await Project.bulkCreate(projectsToCreate);
        
        setUploadStatus({ 
          message: `${projectsToCreate.length} projetos foram adicionados com sucesso!`, 
          type: 'success' 
        });
        setCsvFile(null);
        loadProjects();
      } catch (error) {
        console.error('Erro ao processar o arquivo:', error);
        setUploadStatus({ message: `Erro: ${error.message}`, type: 'error' });
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsText(csvFile);
  };

  const parseCSV = (csvText) => {
    const lines = csvText.split(/\r?\n/);
    const header = lines[0].split(',').map(h => h.trim());
    const rows = lines.slice(1).map(line => {
      const values = line.split(',').map(v => v.trim());
      if (values.length !== header.length) return null;
      let obj = {};
      header.forEach((key, i) => {
        if (key === 'gallery_images' && values[i]) {
          obj[key] = values[i].split(';').map(url => url.trim());
        } else if (key === 'featured') {
          obj[key] = values[i].toLowerCase() === 'true';
        } else if (key === 'year') {
          obj[key] = parseInt(values[i]) || new Date().getFullYear();
        } else {
          obj[key] = values[i];
        }
      });
      return obj;
    }).filter(Boolean);
    return rows;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-charcoal">Gerenciar Projetos</h2>
        <Button onClick={loadProjects} variant="outline">
          Atualizar Lista
        </Button>
      </div>

      <Tabs defaultValue="individual" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="individual">Cadastro Individual</TabsTrigger>
          <TabsTrigger value="bulk">Upload em Massa</TabsTrigger>
          <TabsTrigger value="list">Lista de Projetos</TabsTrigger>
        </TabsList>

        <TabsContent value="individual">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="mr-2 h-5 w-5" />
                Novo Projeto
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProjectSubmit} className="space-y-6">
                {/* Basic Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="title">Título do Projeto *</Label>
                    <Input
                      id="title"
                      value={projectForm.title}
                      onChange={(e) => setProjectForm(prev => ({ ...prev, title: e.target.value }))}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="client">Cliente *</Label>
                    <Input
                      id="client"
                      value={projectForm.client}
                      onChange={(e) => setProjectForm(prev => ({ ...prev, client: e.target.value }))}
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="category">Categoria *</Label>
                    <Select
                      value={projectForm.category}
                      onValueChange={(value) => setProjectForm(prev => ({ ...prev, category: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma categoria" />
                      </SelectTrigger>
                      <SelectContent>
                        {projectCategories.map(cat => (
                          <SelectItem key={cat} value={cat}>
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="year">Ano</Label>
                    <Input
                      id="year"
                      type="number"
                      value={projectForm.year}
                      onChange={(e) => setProjectForm(prev => ({ ...prev, year: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <Label htmlFor="description">Descrição *</Label>
                  <Textarea
                    id="description"
                    value={projectForm.description}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    required
                  />
                </div>

                {/* Challenge & Solution */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="challenge">Desafio</Label>
                    <Textarea
                      id="challenge"
                      value={projectForm.challenge}
                      onChange={(e) => setProjectForm(prev => ({ ...prev, challenge: e.target.value }))}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="solution">Solução</Label>
                    <Textarea
                      id="solution"
                      value={projectForm.solution}
                      onChange={(e) => setProjectForm(prev => ({ ...prev, solution: e.target.value }))}
                      rows={3}
                    />
                  </div>
                </div>

                {/* Materials */}
                <div>
                  <Label htmlFor="materials">Materiais Utilizados</Label>
                  <Input
                    id="materials"
                    value={projectForm.materials}
                    onChange={(e) => setProjectForm(prev => ({ ...prev, materials: e.target.value }))}
                  />
                </div>

                {/* Images */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Imagens</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="main_image">URL da Imagem Principal</Label>
                      <Input
                        id="main_image"
                        type="url"
                        value={projectForm.main_image}
                        onChange={(e) => setProjectForm(prev => ({ ...prev, main_image: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="main_image_file">Ou Faça Upload</Label>
                      <Input
                        id="main_image_file"
                        type="file"
                        accept="image/*"
                        onChange={(e) => setMainImageFile(e.target.files[0])}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="gallery_files">Galeria de Imagens (múltiplas)</Label>
                    <Input
                      id="gallery_files"
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={(e) => setGalleryFiles(e.target.files)}
                    />
                  </div>
                </div>

                {/* Featured */}
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="featured"
                    checked={projectForm.featured}
                    onCheckedChange={(checked) => setProjectForm(prev => ({ ...prev, featured: checked }))}
                  />
                  <Label htmlFor="featured" className="flex items-center">
                    <Star className="mr-1 h-4 w-4" />
                    Projeto em Destaque
                  </Label>
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-primary hover:bg-primary/90"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Cadastrando...
                    </>
                  ) : (
                    <>
                      <Plus className="mr-2 h-4 w-4" />
                      Cadastrar Projeto
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bulk">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Upload className="mr-2 h-5 w-5" />
                Upload em Massa
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="csv-file">Arquivo CSV</Label>
                <Input
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  onChange={(e) => setCsvFile(e.target.files[0])}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Colunas necessárias: title, client, category, description, main_image<br />
                  Opcionais: challenge, solution, materials, gallery_images (URLs separadas por ;), featured (true/false), year
                </p>
              </div>

              <Button 
                onClick={handleCsvUpload} 
                disabled={isLoading || !csvFile}
                className="w-full"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processando...
                  </>
                ) : (
                  <>
                    <FileUp className="mr-2 h-4 w-4" />
                    Enviar Arquivo
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="list">
          <Card>
            <CardHeader>
              <CardTitle>Lista de Projetos ({projects.length})</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                  <p>Carregando projetos...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {projects.map(project => (
                    <div key={project.id} className="border rounded-lg p-4 space-y-2">
                      <img 
                        src={project.main_image} 
                        alt={project.title}
                        className="w-full h-32 object-cover bg-gray-50 rounded"
                        onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80'; }}
                      />
                      <div className="flex items-center justify-between">
                        <h3 className="font-semibold text-sm">{project.title}</h3>
                        {project.featured && (
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                        )}
                      </div>
                      <p className="text-xs text-gray-600">{project.client}</p>
                      <div className="flex justify-between items-center">
                        <Badge variant="outline" className="text-xs">
                          {project.category}
                        </Badge>
                        <span className="text-xs text-gray-500">{project.year}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {uploadStatus.message && (
        <div className={`flex items-center p-4 rounded-md text-sm ${
          uploadStatus.type === 'success' ? 'bg-green-100 text-green-800' :
          uploadStatus.type === 'error' ? 'bg-red-100 text-red-800' :
          'bg-blue-100 text-blue-800'
        }`}>
          {uploadStatus.type === 'success' && <CheckCircle className="mr-2 h-4 w-4" />}
          {uploadStatus.type === 'error' && <AlertCircle className="mr-2 h-4 w-4" />}
          {uploadStatus.message}
        </div>
      )}
    </div>
  );
}