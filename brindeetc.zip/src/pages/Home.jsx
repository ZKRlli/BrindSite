
import React, { useState, useEffect } from "react";
import { base44 } from '@/api/base44Client';
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight, Badge as BadgeIcon } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";

import HeroSection from "../components/home/HeroSection";
import FeaturedProjects from "../components/home/FeaturedProjects";
import TestimonialsSection from "../components/home/TestimonialsSection";
import ProcessSection from "../components/home/ProcessSection";
import FeaturedProductsHome from "../components/home/FeaturedProductsHome";
import ProductDetailModal from "../components/products/ProductDetailModal";

export default function HomePage() {
  const [featuredProjects, setFeaturedProjects] = useState([]);
  const [recentPosts, setRecentPosts] = useState([]);
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [projects, posts, products] = await Promise.all([
        base44.entities.Project.filter({ featured: true }, '-created_date', 6),
        base44.entities.BlogPost.filter({ published: true }, '-created_date', 3),
        base44.entities.Product.list('-created_date', 100)
      ]);
      
      // Filtrar produtos com estoque > 0
      const productsWithStock = products.filter(p => {
        const stock = p.AvailableGross || p.available_quantity || 0;
        return stock > 0;
      });
      
      const shuffledProducts = productsWithStock.sort(() => 0.5 - Math.random());
      const randomProducts = shuffledProducts.slice(0, 10);

      setFeaturedProjects(projects);
      setRecentPosts(posts);
      setFeaturedProducts(randomProducts);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleViewDetails = (product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen">
      <HeroSection />
      <FeaturedProjects projects={featuredProjects} isLoading={isLoading} />
      <FeaturedProductsHome 
        products={featuredProducts} 
        isLoading={isLoading}
        onViewDetails={handleViewDetails}
      />
      <ProcessSection />
      <TestimonialsSection />

      {/* Blog Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Blog.etc
            </h2>
            <p className="text-gray-600 text-base max-w-2xl mx-auto">
              Insights, tendências e dicas especializadas sobre o universo dos presentes corporativos e experiências memoráveis.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-sm animate-pulse border">
                  <div className="aspect-[16/10] bg-gray-200 rounded-t-lg mb-4"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              ))
            ) : (
              recentPosts.map((post) => (
                <motion.article
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                  className="bg-white rounded-lg overflow-hidden hover:shadow-xl transition-all duration-300 group border border-gray-100"
                >
                  <div className="relative aspect-[16/10] overflow-hidden">
                    <img
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <Badge className="absolute top-4 left-4 bg-primary text-white border-0 uppercase text-xs font-semibold">
                      {post.category}
                    </Badge>
                  </div>
                  <div className="p-6">
                    <h3 className="font-semibold text-lg text-charcoal mb-2 group-hover:text-primary transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-600 text-sm leading-relaxed line-clamp-2">
                      {post.excerpt}
                    </p>
                    <div className="mt-4 flex items-center text-primary text-sm font-medium">
                      Ler mais →
                    </div>
                  </div>
                </motion.article>
              ))
            )}
          </div>

          <div className="text-center mt-12">
            <Link to={createPageUrl("Blog")}>
              <Button className="bg-gradient-pink-purple hover:opacity-90 text-white font-medium px-8 rounded-full">
                Ver Todos os Artigos →
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setTimeout(() => setSelectedProduct(null), 300);
        }}
      />
    </div>
  );
}
