import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Package, Briefcase, LogOut, Plus, Upload, 
  BarChart3, Users, FileText, Settings
} from 'lucide-react';
import { createPageUrl } from '@/utils';

import ProductManager from '../components/admin/ProductManager';
import ProjectManager from '../components/admin/ProjectManager';
import HeroBannerManager from '../components/admin/HeroBannerManager';

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    } catch (error) {
      await base44.auth.redirectToLogin();
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
      window.location.href = createPageUrl('Home');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const tabs = [
    { id: 'overview', title: 'Visão Geral', icon: BarChart3 },
    { id: 'hero', title: 'Banner Hero', icon: FileText },
    { id: 'products', title: 'Produtos', icon: Package },
    { id: 'projects', title: 'Projetos', icon: Briefcase },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68a4926f7506dfd8882872d0/07d602208_BrindLogo_Final-03.png" 
                alt="Brind.etc" 
                className="h-8 w-auto mr-4"
              />
              <h1 className="text-xl font-semibold text-charcoal">
                Painel Administrativo
              </h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Olá, {user.full_name}
              </span>
              <Button onClick={handleLogout} variant="outline" size="sm">
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-8 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'bg-primary text-white' 
                  : 'bg-white text-gray-600 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="h-4 w-4" />
              <span>{tab.title}</span>
            </button>
          ))}
        </div>

        {/* Content */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-primary" />
                  Banner Hero
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 text-sm">
                  Gerencie as imagens e textos do banner principal da página inicial
                </p>
                <Button onClick={() => setActiveTab('hero')} className="w-full bg-primary hover:bg-primary/90">
                  Gerenciar Banner
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Package className="h-5 w-5 mr-2 text-primary" />
                  Produtos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 text-sm">
                  Gerencie o catálogo de produtos disponíveis
                </p>
                <Button onClick={() => setActiveTab('products')} className="w-full bg-primary hover:bg-primary/90">
                  Gerenciar Produtos
                </Button>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Briefcase className="h-5 w-5 mr-2 text-primary" />
                  Projetos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4 text-sm">
                  Adicione e edite trabalhos realizados no portfolio
                </p>
                <Button onClick={() => setActiveTab('projects')} className="w-full bg-primary hover:bg-primary/90">
                  Gerenciar Projetos
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === 'hero' && <HeroBannerManager />}
        {activeTab === 'products' && <ProductManager />}
        {activeTab === 'projects' && <ProjectManager />}
      </div>
    </div>
  );
}