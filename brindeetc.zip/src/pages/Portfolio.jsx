
import React, { useState, useEffect } from "react";
import { Project } from "@/api/entities";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { ExternalLink } from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

const categoryLabels = {
  todos: "Todos",
  corporativo: "Corporativo",
  casamento: "Casamentos",
  festa: "Festas",
  aniversario: "Aniversários",
  outros: "Outros"
};

const categories = ["todos", "corporativo", "casamento", "festa", "aniversario"];

export default function PortfolioPage() {
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [activeCategory, setActiveCategory] = useState("todos");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadProjects = async () => {
      setIsLoading(true);
      try {
        const fetchedProjects = await Project.list("-created_date");
        setProjects(fetchedProjects);
        setFilteredProjects(fetchedProjects);
      } catch (error) {
        console.error("Erro ao carregar projetos:", error);
      }
      setIsLoading(false);
    };
    loadProjects();
  }, []);

  const handleFilter = (category) => {
    setActiveCategory(category);
    if (category === "todos") {
      setFilteredProjects(projects);
    } else {
      setFilteredProjects(projects.filter(p => p.category === category));
    }
  };

  return (
    <div className="bg-white text-charcoal">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-50 to-pink-50 text-center py-20 lg:py-28">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto px-4"
        >
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Nossos Trabalhos
          </h1>
          <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
            Explore uma seleção de projetos que demonstram nossa paixão por design, qualidade e atenção aos detalhes.
          </p>
        </motion.div>
      </section>

      {/* Gallery */}
      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4">
          {/* Filters */}
          <div className="flex justify-center mb-12">
            <Tabs value={activeCategory} onValueChange={handleFilter}>
              <TabsList className="bg-white border-2 border-gray-200 p-1.5 shadow-sm">
                {categories.map(cat => (
                  <TabsTrigger 
                    key={cat} 
                    value={cat} 
                    className="capitalize px-6 py-2 text-sm font-medium data-[state=active]:bg-gradient-pink-purple data-[state=active]:text-white"
                  >
                    {categoryLabels[cat]}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>

          {/* Projects Grid */}
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {isLoading ? (
              Array(9).fill(0).map((_, i) => (
                <div key={i} className="bg-gray-100 rounded-xl animate-pulse">
                  <div className="aspect-[4/3] bg-gray-200 rounded-t-xl mb-4"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              ))
            ) : (
              filteredProjects.map((project, index) => (
                <motion.div
                  layout
                  key={project.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4 }}
                  className="group bg-gray-50/50 rounded-xl shadow-sm hover:shadow-lg transition-smooth overflow-hidden"
                >
                  <div className="relative aspect-[4/3] overflow-hidden">
                    <img
                      src={project.main_image}
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  
                  <div className="p-6">
                    <Badge variant="outline" className="mb-3 border-primary/20 text-primary bg-primary/5">
                      {categoryLabels[project.category]}
                    </Badge>
                    <h3 className="font-semibold text-lg text-charcoal mb-2 group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                      {project.description}
                    </p>
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span>{project.client}</span>
                      <ExternalLink className="h-4 w-4 group-hover:text-primary transition-colors" />
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </motion.div>
        </div>
      </section>
    </div>
  );
}
