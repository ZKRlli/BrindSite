import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, Mail, Clock, CheckCircle, Calendar } from "lucide-react";
import { motion } from "framer-motion";

const WHATSAPP_NUMBER = "5511998148242";
const WHATSAPP_MESSAGE = encodeURIComponent("Olá! Vim pelo site e gostaria de mais informações.");
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`;

// Configuração da API do aplicativo interno
const INTERNAL_APP_CONFIG = {
  apiUrl: 'https://app.base44.com/api/apps/68d55a26ec02082aa6dd3d12/entities/Quote',
  apiKey: '36c3535b58334160a0287557dbab91ad'
};

// Função para criar orçamento no app interno
const createInternalQuote = async (quoteData) => {
  try {    
    const internalQuoteData = {
      quote_number: `FORM-${Date.now()}`,
      client_name: quoteData.name,
      client_email: quoteData.email || '',
      client_phone: quoteData.phone || '',
      product_name: `${quoteData.event_type} - Via formulário de contato`,
      delivery_date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // Campo obrigatório: 15 dias
      items: [{
        name: `Orçamento: ${quoteData.event_type}`,
        quantity: 1,
        unit_price: 0,
        total_price: 0,
        notes: `Quantidade estimada: ${quoteData.estimated_quantity || 'N/A'} | Orçamento: ${quoteData.budget_range || 'N/A'}`
      }],
      custom_notes: `
Empresa: ${quoteData.company || 'N/A'}
Tipo de evento: ${quoteData.event_type}
Quantidade estimada: ${quoteData.estimated_quantity || 'N/A'}
Orçamento: ${quoteData.budget_range || 'N/A'}

Mensagem:
${quoteData.message}

⚠️ ATENÇÃO: Valores devem ser preenchidos manualmente após análise
      `.trim(),
      status: 'pendente',
      urgency: 'normal',
      valid_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    };

    const response = await fetch(INTERNAL_APP_CONFIG.apiUrl, {
      method: 'POST',
      headers: {
        'api_key': INTERNAL_APP_CONFIG.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(internalQuoteData)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erro na API: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log('✅ Orçamento criado no app interno com sucesso!');
    
    return result;
  } catch (error) {
    console.error('❌ Erro ao criar orçamento no app interno:', error);
    // Não mostrar alerta - deixar silencioso
    return null;
  }
};

export default function ContactPage() {
  const [quoteForm, setQuoteForm] = useState({
    name: "",
    company: "",
    email: "",
    phone: "",
    event_type: "",
    estimated_quantity: "",
    budget_range: "",
    message: ""
  });

  const [consultationForm, setConsultationForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
    preferred_date: "",
    preferred_time: ""
  });

  const [isSubmitting, setIsSubmitting] = useState({ quote: false, consultation: false });
  const [submitSuccess, setSubmitSuccess] = useState({ quote: false, consultation: false });

  const handleQuoteSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(prev => ({ ...prev, quote: true }));

    try {
      await base44.entities.QuoteRequest.create(quoteForm);
      await createInternalQuote(quoteForm);
      
      await base44.integrations.Core.SendEmail({
        to: quoteForm.email,
        subject: "Recebemos sua solicitação de orçamento - Brind.etc",
        body: `Olá ${quoteForm.name},\n\nObrigada por entrar em contato conosco! Recebemos sua solicitação de orçamento e nossa equipe entrará em contato em até 24 horas.\n\nDetalhes da sua solicitação:\n- Tipo de evento: ${quoteForm.event_type}\n- Quantidade estimada: ${quoteForm.estimated_quantity}\n- Orçamento: ${quoteForm.budget_range}\n\nAtenciosamente,\nEquipe Brind.etc`
      });

      setSubmitSuccess(prev => ({ ...prev, quote: true }));
      setQuoteForm({
        name: "", company: "", email: "", phone: "",
        event_type: "", estimated_quantity: "", budget_range: "", message: ""
      });
      
    } catch (error) {
      console.error('❌ Erro ao enviar solicitação:', error);
    }

    setIsSubmitting(prev => ({ ...prev, quote: false }));
  };

  const handleConsultationSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(prev => ({ ...prev, consultation: true }));

    try {
      await base44.entities.ConsultationRequest.create(consultationForm);
      
      await base44.integrations.Core.SendEmail({
        to: consultationForm.email,
        subject: "Consultoria agendada - Brind.etc",
        body: `Olá ${consultationForm.name},\n\nObrigada por agendar uma consultoria conosco! Nossa equipe entrará em contato para confirmar o horário.\n\nData preferencial: ${consultationForm.preferred_date}\nHorário preferencial: ${consultationForm.preferred_time}\n\nAtenciosamente,\nEquipe Brind.etc`
      });

      setSubmitSuccess(prev => ({ ...prev, consultation: true }));
      setConsultationForm({
        name: "", email: "", phone: "", message: "",
        preferred_date: "", preferred_time: ""
      });
    } catch (error) {
      console.error('Erro ao agendar consultoria:', error);
    }

    setIsSubmitting(prev => ({ ...prev, consultation: false }));
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-50 to-pink-50 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-serif text-4xl md:text-5xl font-bold text-charcoal mb-6"
          >
            Vamos Conversar?
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-lg text-gray-600 max-w-2xl mx-auto"
          >
            Estamos prontos para criar algo extraordinário para você. Escolha a melhor forma de iniciarmos nossa conversa.
          </motion.p>
        </div>
      </section>

      {/* Contact Forms */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Quote Request Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <Card className="h-full shadow-2xl border-2 border-primary/30 hover:border-primary/50 transition-all duration-300">
                <CardHeader className="bg-gradient-pink-purple text-white rounded-t-xl">
                  <CardTitle className="text-2xl font-bold flex items-center">
                    <div className="bg-white/20 p-2 rounded-lg mr-3">
                      <Mail className="h-6 w-6" />
                    </div>
                    Peça um Orçamento
                  </CardTitle>
                  <p className="text-white/90 text-sm mt-2">
                    Para projetos corporativos e eventos especiais
                  </p>
                </CardHeader>
                <CardContent className="p-6">
                  {submitSuccess.quote ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-charcoal mb-2">
                        Solicitação Enviada!
                      </h3>
                      <p className="text-gray-600">
                        Entraremos em contato em até 24 horas.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleQuoteSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="quote-name">Nome completo *</Label>
                          <Input
                            id="quote-name"
                            value={quoteForm.name}
                            onChange={(e) => setQuoteForm(prev => ({ ...prev, name: e.target.value }))}
                            required
                            className="border-gray-300 focus:border-primary focus:ring-primary"
                          />
                        </div>
                        <div>
                          <Label htmlFor="quote-company">Empresa</Label>
                          <Input
                            id="quote-company"
                            value={quoteForm.company}
                            onChange={(e) => setQuoteForm(prev => ({ ...prev, company: e.target.value }))}
                            className="border-gray-300 focus:border-primary"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="quote-email">E-mail *</Label>
                          <Input
                            id="quote-email"
                            type="email"
                            value={quoteForm.email}
                            onChange={(e) => setQuoteForm(prev => ({ ...prev, email: e.target.value }))}
                            required
                            className="border-gray-300 focus:border-primary"
                          />
                        </div>
                        <div>
                          <Label htmlFor="quote-phone">Telefone</Label>
                          <Input
                            id="quote-phone"
                            value={quoteForm.phone}
                            onChange={(e) => setQuoteForm(prev => ({ ...prev, phone: e.target.value }))}
                            className="border-gray-300 focus:border-primary"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="quote-event-type">Tipo de evento *</Label>
                        <Select
                          value={quoteForm.event_type}
                          onValueChange={(value) => setQuoteForm(prev => ({ ...prev, event_type: value }))}
                        >
                          <SelectTrigger className="border-gray-300 focus:border-primary">
                            <SelectValue placeholder="Selecione o tipo de evento" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="corporativo">Corporativo</SelectItem>
                            <SelectItem value="casamento">Casamento</SelectItem>
                            <SelectItem value="festa">Festa</SelectItem>
                            <SelectItem value="aniversario">Aniversário</SelectItem>
                            <SelectItem value="outros">Outros</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="quote-quantity">Quantidade estimada</Label>
                          <Input
                            id="quote-quantity"
                            placeholder="Ex: 100 unidades"
                            value={quoteForm.estimated_quantity}
                            onChange={(e) => setQuoteForm(prev => ({ ...prev, estimated_quantity: e.target.value }))}
                            className="border-gray-300 focus:border-primary"
                          />
                        </div>
                        <div>
                          <Label htmlFor="quote-budget">Orçamento</Label>
                          <Select
                            value={quoteForm.budget_range}
                            onValueChange={(value) => setQuoteForm(prev => ({ ...prev, budget_range: value }))}
                          >
                            <SelectTrigger className="border-gray-300 focus:border-primary">
                              <SelectValue placeholder="Faixa de investimento" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="ate-1000">Até R$ 1.000</SelectItem>
                              <SelectItem value="1000-5000">R$ 1.000 - R$ 5.000</SelectItem>
                              <SelectItem value="5000-15000">R$ 5.000 - R$ 15.000</SelectItem>
                              <SelectItem value="15000-plus">Acima de R$ 15.000</SelectItem>
                              <SelectItem value="consultar">Consultar</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="quote-message">Detalhes do projeto *</Label>
                        <Textarea
                          id="quote-message"
                          placeholder="Conte-nos mais sobre seu projeto, objetivos e expectativas..."
                          value={quoteForm.message}
                          onChange={(e) => setQuoteForm(prev => ({ ...prev, message: e.target.value }))}
                          rows={4}
                          required
                          className="border-gray-300 focus:border-primary"
                        />
                      </div>

                      <Button
                        type="submit"
                        className="w-full bg-gradient-pink-purple hover:opacity-90 text-white font-semibold py-6 text-base border-0 shadow-lg"
                        disabled={isSubmitting.quote}
                      >
                        {isSubmitting.quote ? "Enviando..." : "Solicitar Orçamento →"}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </motion.div>

            {/* Consultation Request Form */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <Card className="h-full shadow-2xl border-2 border-purple-300/50 hover:border-purple-400 transition-all duration-300">
                <CardHeader className="bg-gradient-to-r from-purple-600 to-purple-500 text-white rounded-t-xl">
                  <CardTitle className="text-2xl font-bold flex items-center">
                    <div className="bg-white/20 p-2 rounded-lg mr-3">
                      <Calendar className="h-6 w-6" />
                    </div>
                    Agende uma Consultoria
                  </CardTitle>
                  <p className="text-white/90 text-sm mt-2">
                    Para uma conversa mais detalhada sobre seu projeto
                  </p>
                </CardHeader>
                <CardContent className="p-6">
                  {submitSuccess.consultation ? (
                    <div className="text-center py-8">
                      <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-charcoal mb-2">
                        Consultoria Agendada!
                      </h3>
                      <p className="text-gray-600">
                        Entraremos em contato para confirmar o horário.
                      </p>
                    </div>
                  ) : (
                    <form onSubmit={handleConsultationSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="consultation-name">Nome completo *</Label>
                        <Input
                          id="consultation-name"
                          value={consultationForm.name}
                          onChange={(e) => setConsultationForm(prev => ({ ...prev, name: e.target.value }))}
                          required
                          className="border-gray-300 focus:border-purple-500"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="consultation-email">E-mail *</Label>
                          <Input
                            id="consultation-email"
                            type="email"
                            value={consultationForm.email}
                            onChange={(e) => setConsultationForm(prev => ({ ...prev, email: e.target.value }))}
                            required
                            className="border-gray-300 focus:border-purple-500"
                          />
                        </div>
                        <div>
                          <Label htmlFor="consultation-phone">Telefone</Label>
                          <Input
                            id="consultation-phone"
                            value={consultationForm.phone}
                            onChange={(e) => setConsultationForm(prev => ({ ...prev, phone: e.target.value }))}
                            className="border-gray-300 focus:border-purple-500"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="consultation-date">Data preferencial</Label>
                          <Input
                            id="consultation-date"
                            type="date"
                            value={consultationForm.preferred_date}
                            onChange={(e) => setConsultationForm(prev => ({ ...prev, preferred_date: e.target.value }))}
                            className="border-gray-300 focus:border-purple-500"
                          />
                        </div>
                        <div>
                          <Label htmlFor="consultation-time">Horário preferencial</Label>
                          <Select
                            value={consultationForm.preferred_time}
                            onValueChange={(value) => setConsultationForm(prev => ({ ...prev, preferred_time: value }))}
                          >
                            <SelectTrigger className="border-gray-300 focus:border-purple-500">
                              <SelectValue placeholder="Selecione o horário" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="manha">Manhã (9h - 12h)</SelectItem>
                              <SelectItem value="tarde">Tarde (14h - 17h)</SelectItem>
                              <SelectItem value="flexivel">Horário flexível</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="consultation-message">Mensagem adicional</Label>
                        <Textarea
                          id="consultation-message"
                          placeholder="Conte-nos um pouco sobre seu projeto ou dúvidas..."
                          value={consultationForm.message}
                          onChange={(e) => setConsultationForm(prev => ({ ...prev, message: e.target.value }))}
                          rows={4}
                          className="border-gray-300 focus:border-purple-500"
                        />
                      </div>

                      <Button
                        type="submit"
                        className="w-full bg-gradient-to-r from-purple-600 to-purple-500 hover:opacity-90 text-white font-semibold py-6 text-base shadow-lg"
                        disabled={isSubmitting.consultation}
                      >
                        {isSubmitting.consultation ? "Agendando..." : "Agendar Consultoria →"}
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl font-bold text-charcoal mb-4">
              Outras Formas de Contato
            </h2>
            <p className="text-gray-600">
              Estamos sempre disponíveis para esclarecer suas dúvidas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center p-6 bg-white rounded-xl shadow-md border border-gray-100 hover:shadow-xl hover:border-primary/30 transition-all cursor-pointer group"
            >
              <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-charcoal mb-2">WhatsApp</h3>
              <p className="text-gray-600">+55 11 99814-8242</p>
              <p className="text-xs text-gray-500 mt-2">Clique para conversar</p>
            </motion.a>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-center p-6 bg-white rounded-xl shadow-md border border-gray-100 hover:shadow-xl transition-shadow"
            >
              <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-charcoal mb-2">E-mail</h3>
              <p className="text-gray-600">contato@brind.etc.br</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center p-6 bg-white rounded-xl shadow-md border border-gray-100 hover:shadow-xl transition-shadow"
            >
              <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-charcoal mb-2">Atendimento</h3>
              <p className="text-gray-600">Seg - Sex: 9h às 18h</p>
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
}