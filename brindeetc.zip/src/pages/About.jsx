import React from "react";
import { motion } from "framer-motion";
import { Sparkles, Heart, Users, Target } from "lucide-react";

const founders = [
  {
    name: "Ingrid Moreno",
    role: "Co-fundadora & Designer de Moda",
    bio: "Com formação em Design de Moda e paixão por criar experiências únicas, Ingrid traz sensibilidade estética e atenção aos detalhes que transformam cada projeto em uma obra de arte. Sua expertise em tecidos, cores e tendências garante que cada brinde conte uma história visual impactante.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d94c0b420c67a83c3c78fe/8dc935718_ingrid.jpg",
    imagePosition: "object-center"
  },
  {
    name: "Marco Zicarelli",
    role: "Co-fundador & Designer Gráfico e Publicitário",
    bio: "Designer Gráfico e Publicitário com vasta experiência em branding e comunicação visual. Marco é responsável por traduzir a essência das marcas em projetos que comunicam, emocionam e conectam. Sua visão estratégica garante que cada presente corporativo seja uma extensão autêntica da identidade do cliente.",
    image: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d94c0b420c67a83c3c78fe/03a2e8230_Gemini_Generated_Image_7yyvlx7yyvlx7yyv.png",
    imagePosition: "object-top"
  }
];

const values = [
  {
    icon: Heart,
    title: "Paixão pelo Detalhe",
    description: "Cada projeto é único e merece atenção especial. Cuidamos de cada detalhe para garantir que seu presente conte exatamente a história que você quer transmitir."
  },
  {
    icon: Users,
    title: "Parceria Verdadeira",
    description: "Mais do que fornecedores, somos parceiros na criação de experiências memoráveis. Trabalhamos lado a lado com você do conceito à entrega."
  },
  {
    icon: Sparkles,
    title: "Criatividade sem Limites",
    description: "Transformamos ideias em realidade. Nossa equipe criativa está sempre buscando soluções inovadoras e personalizadas para cada cliente."
  },
  {
    icon: Target,
    title: "Compromisso com Resultados",
    description: "Seu sucesso é nosso sucesso. Trabalhamos com prazos, qualidade e orçamento para garantir que cada projeto supere expectativas."
  }
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-50 to-pink-50 py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-serif text-4xl md:text-5xl font-bold text-charcoal mb-6"
          >
            Presentes que Contam Histórias
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-lg text-gray-600 leading-relaxed"
          >
            Somos apaixonados por transformar momentos especiais em memórias inesquecíveis através de presentes corporativos e eventos únicos.
          </motion.p>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="prose prose-lg max-w-none"
          >
            <h2 className="font-serif text-3xl font-bold text-charcoal mb-6">Nossa História</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              A Brind.etc nasceu da união de duas paixões: design e conexão humana. Fundada por Ingrid Moreno e Marco Zicarelli, nossa empresa surgiu da percepção de que presentes corporativos poderiam ser muito mais do que simples brindes — eles poderiam ser experiências que fortalecem relacionamentos e contam histórias.
            </p>
            <p className="text-gray-600 leading-relaxed mb-4">
              Com backgrounds em Design de Moda e Design Gráfico/Publicidade, trouxemos uma abordagem única ao mercado: combinar estética sofisticada, estratégia de comunicação e atenção aos detalhes para criar presentes que realmente fazem a diferença.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Hoje, trabalhamos com empresas de diversos segmentos, sempre com o mesmo propósito: transformar cada projeto em uma oportunidade de criar conexões genuínas e memórias duradouras.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Founders Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Conheça os Fundadores
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              A união de criatividade, estratégia e paixão pelo que fazemos
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {founders.map((founder, index) => (
              <motion.div
                key={founder.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all"
              >
                <div className="aspect-square overflow-hidden">
                  <img
                    src={founder.image}
                    alt={founder.name}
                    className={`w-full h-full object-cover ${founder.imagePosition} hover:scale-105 transition-transform duration-500`}
                  />
                </div>
                <div className="p-8">
                  <h3 className="font-serif text-2xl font-bold text-charcoal mb-2">
                    {founder.name}
                  </h3>
                  <p className="text-primary font-semibold mb-4">{founder.role}</p>
                  <p className="text-gray-600 leading-relaxed">{founder.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Nossos Valores
            </h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Os princípios que guiam cada projeto e decisão
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 hover:shadow-lg transition-all"
              >
                <div className="w-14 h-14 bg-gradient-pink-purple rounded-full flex items-center justify-center mb-4">
                  <value.icon className="h-7 w-7 text-white" />
                </div>
                <h3 className="font-serif text-xl font-bold text-charcoal mb-3">
                  {value.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}