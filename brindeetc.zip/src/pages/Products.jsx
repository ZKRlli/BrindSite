import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Card } from '@/components/ui/card';
import { 
  Search, ChevronLeft, ChevronRight, Package, X, 
  SlidersHorizontal, ChevronDown, ChevronUp, ShoppingCart,
  Star, TrendingUp
} from 'lucide-react';
import ProductDetailModal from '../components/products/ProductDetailModal';
import ProductCarousel from '../components/products/ProductCarousel';

const useDebounce = (value, delay) => {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
};

const SPOTGIFTS_IMAGE_BASE = 'https://www.spotgifts.com.br/fotos/produtos/';

const getProductImageUrl = (imageUrl) => {
  if (!imageUrl) return 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60';
  if (imageUrl.startsWith('http')) return imageUrl;
  return `${SPOTGIFTS_IMAGE_BASE}${imageUrl}`;
};

// Mapa de cores - MESMA FUNÇÃO DO MODAL
const getColorHex = (colorName) => {
  const colorMap = {
    'branco': '#FFFFFF', 'preto': '#000000', 'cinza': '#808080',
    'vermelho': '#FF0000', 'azul': '#0000FF', 'verde': '#00FF00',
    'amarelo': '#FFFF00', 'laranja': '#FFA500', 'rosa': '#FFC0CB',
    'roxo': '#800080', 'marrom': '#8B4513', 'bege': '#F5F5DC',
    'white': '#FFFFFF', 'black': '#000000', 'grey': '#808080', 'gray': '#808080',
    'red': '#FF0000', 'blue': '#0000FF', 'green': '#00FF00',
    'yellow': '#FFFF00', 'orange': '#FFA500', 'pink': '#FFC0CB',
    'purple': '#800080', 'brown': '#8B4513', 'navy': '#000080',
    'lime': '#32CD32', 'silver': '#C0C0C0', 'gold': '#FFD700', 'beige': '#F5F5DC',
    'azul marinho': '#000080', 'azul royal': '#4169E1', 'azul escuro': '#00008B',
    'verde escuro': '#006400', 'vermelho escuro': '#8B0000', 'cinza escuro': '#A9A9A9',
    'amarelo escuro': '#B8860B', 'laranja escuro': '#FF8C00', 'rosa escuro': '#C71585',
    'roxo escuro': '#4B0082', 'marrom escuro': '#654321',
    'azul claro': '#ADD8E6', 'verde claro': '#90EE90', 'vermelho claro': '#FF6B6B',
    'cinza claro': '#D3D3D3', 'amarelo claro': '#FFFFE0', 'laranja claro': '#FFDAB9',
    'rosa claro': '#FFB6C1', 'roxo claro': '#DDA0DD', 'marrom claro': '#D2B48C',
    'light blue': '#ADD8E6', 'light green': '#90EE90', 'light red': '#FF6B6B',
    'light gray': '#D3D3D3', 'light grey': '#D3D3D3', 'light yellow': '#FFFFE0',
    'light orange': '#FFDAB9', 'light pink': '#FFB6C1', 'light purple': '#DDA0DD',
    'light brown': '#D2B48C', 'dark blue': '#00008B', 'dark green': '#006400',
    'dark red': '#8B0000', 'dark gray': '#A9A9A9', 'dark grey': '#A9A9A9',
    'dark yellow': '#B8860B', 'dark orange': '#FF8C00', 'dark pink': '#C71585',
    'dark purple': '#4B0082', 'dark brown': '#654321',
    'azul celeste': '#87CEEB', 'azul turquesa': '#40E0D0', 'azul petróleo': '#008B8B',
    'sky blue': '#87CEEB', 'turquoise': '#40E0D0', 'teal': '#008080',
    'cyan': '#00FFFF', 'aqua': '#00FFFF', 'verde limão': '#32CD32',
    'verde musgo': '#8FBC8F', 'verde oliva': '#808000', 'lime green': '#32CD32',
    'olive': '#808000', 'mint': '#98FF98', 'vermelho vinho': '#722F37',
    'coral': '#FF7F50', 'carmesim': '#DC143C', 'crimson': '#DC143C',
    'burgundy': '#800020', 'creme': '#FFFDD0', 'marfim': '#FFFFF0',
    'off white': '#FAF9F6', 'cream': '#FFFDD0', 'ivory': '#FFFFF0',
    'dourado': '#FFD700', 'prateado': '#C0C0C0', 'bronze': '#CD7F32', 'cobre': '#B87333',
  };
  
  const normalizedName = colorName?.toLowerCase().trim() || '';
  if (colorMap[normalizedName]) return colorMap[normalizedName];
  
  // Detectar padrões "X claro"
  const lightPatternPt = normalizedName.match(/^(.+)\s+claro$/);
  if (lightPatternPt) {
    const lightColorMap = {
      'azul': '#ADD8E6', 'verde': '#90EE90', 'vermelho': '#FF6B6B',
      'amarelo': '#FFFFE0', 'laranja': '#FFDAB9', 'rosa': '#FFB6C1',
      'roxo': '#DDA0DD', 'marrom': '#D2B48C', 'cinza': '#D3D3D3',
    };
    if (lightColorMap[lightPatternPt[1]]) return lightColorMap[lightPatternPt[1]];
  }
  
  // Detectar padrões "light X"
  const lightPatternEn = normalizedName.match(/^light\s+(.+)$/);
  if (lightPatternEn) {
    const lightColorMap = {
      'blue': '#ADD8E6', 'green': '#90EE90', 'red': '#FF6B6B',
      'yellow': '#FFFFE0', 'orange': '#FFDAB9', 'pink': '#FFB6C1',
      'purple': '#DDA0DD', 'brown': '#D2B48C', 'gray': '#D3D3D3', 'grey': '#D3D3D3',
    };
    if (lightColorMap[lightPatternEn[1]]) return lightColorMap[lightPatternEn[1]];
  }
  
  // Detectar padrões "X escuro"
  const darkPatternPt = normalizedName.match(/^(.+)\s+escuro$/);
  if (darkPatternPt) {
    const darkColorMap = {
      'azul': '#00008B', 'verde': '#006400', 'vermelho': '#8B0000',
      'amarelo': '#B8860B', 'laranja': '#FF8C00', 'rosa': '#C71585',
      'roxo': '#4B0082', 'marrom': '#654321', 'cinza': '#A9A9A9',
    };
    if (darkColorMap[darkPatternPt[1]]) return darkColorMap[darkPatternPt[1]];
  }
  
  // Detectar padrões "dark X"
  const darkPatternEn = normalizedName.match(/^dark\s+(.+)$/);
  if (darkPatternEn) {
    const darkColorMap = {
      'blue': '#00008B', 'green': '#006400', 'red': '#8B0000',
      'yellow': '#B8860B', 'orange': '#FF8C00', 'pink': '#C71585',
      'purple': '#4B0082', 'brown': '#654321', 'gray': '#A9A9A9', 'grey': '#A9A9A9',
    };
    if (darkColorMap[darkPatternEn[1]]) return darkColorMap[darkPatternEn[1]];
  }
  
  return '#CCCCCC';
};

// Função para gerar referência customizada
const generateDisplayReference = (product) => {
  if (!product.id) {
    return `BE-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
  }
  const idStr = product.id.toString();
  const numericPart = idStr.slice(-4).padStart(4, '0');
  return `BE-${numericPart}`;
};

const ProductCard = React.memo(({ product, onViewDetails }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  
  const getImageUrl = () => {
    if (imageError) return 'https://images.unsplash.com/photo-1588949869355-32939b45a498?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=60';
    return getProductImageUrl(product.MainImage || product.image_url);
  };

  const displayReference = generateDisplayReference(product);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3 }}
      className="group bg-white rounded-lg hover:shadow-xl transition-all overflow-hidden flex flex-col border border-gray-100 cursor-pointer"
      onClick={() => onViewDetails(product)}
    >
      <div className="relative aspect-square overflow-hidden bg-gray-50">
        {!imageLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        )}
        <img
          src={getImageUrl()}
          alt={product.Name || product.name}
          className={`w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-500 ${
            imageLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          onError={() => {
            setImageError(true);
            setImageLoaded(true);
          }}
        />
        {product.featured && (
          <Badge className="absolute top-2 right-2 bg-yellow-500 text-white border-0">
            <Star className="h-3 w-3 mr-1" />
            Destaque
          </Badge>
        )}
      </div>

      <div className="p-4 flex flex-col flex-grow">
        <div className="mb-3">
          <p className="text-xs text-gray-500 font-mono mb-1">
            Ref: {displayReference}
          </p>
          <h3 className="font-semibold text-sm text-charcoal line-clamp-2 group-hover:text-primary transition-colors mb-2">
            {product.Name || product.name}
          </h3>
        </div>

        <div className="flex flex-wrap gap-1 mb-3">
          {product.Brand && (
            <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
              Brind.etc™
            </Badge>
          )}
          {product.Type && (
            <Badge variant="outline" className="text-xs bg-gray-50 text-gray-700 border-gray-200">
              {product.Type}
            </Badge>
          )}
        </div>

        {/* Colors - AGORA COM getColorHex */}
        {product.Colors && product.Colors.length > 0 && (
          <div className="mb-3">
            <p className="text-xs text-gray-500 mb-1">Cores:</p>
            <div className="flex flex-wrap gap-1">
              {product.Colors.slice(0, 6).map((color, idx) => {
                const colorHex = color.HexCode || getColorHex(color.Name);
                return (
                  <div
                    key={idx}
                    className="w-5 h-5 rounded-full border border-gray-300 cursor-pointer hover:scale-110 transition-transform"
                    style={{ backgroundColor: colorHex }}
                    title={color.Name}
                  />
                );
              })}
              {product.Colors.length > 6 && (
                <span className="text-xs text-gray-500 self-center">+{product.Colors.length - 6}</span>
              )}
            </div>
          </div>
        )}
        
        <div className="mt-auto space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-600">
            <span>
              {product.AvailableGross > 0 ? (
                <span className="text-green-600 font-medium">
                  ✓ {product.AvailableGross} un
                </span>
              ) : (
                <span className="text-red-600">Sob consulta</span>
              )}
            </span>
            {product.Materials && (
              <span className="text-gray-500 truncate max-w-[100px]" title={product.Materials}>
                {product.Materials.split(',')[0]}
              </span>
            )}
          </div>

          <Button
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails(product);
            }}
            className="w-full bg-primary hover:bg-primary/90 text-white text-sm"
            size="sm"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Ver Detalhes
          </Button>
        </div>
      </div>
    </motion.div>
  );
});

const FilterSection = ({ title, children, defaultOpen = true }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  
  return (
    <div className="border-b border-gray-200 pb-4 mb-4">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full mb-3 font-semibold text-sm text-charcoal"
      >
        {title}
        {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default function ProductsPage() {
  const [filters, setFilters] = useState({ 
    search: '', 
    types: [],
    subTypes: [],
    brands: [],
    countries: [],
    materials: []
  });
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(24);
  const [sortBy, setSortBy] = useState('-created_date');
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const debouncedSearch = useDebounce(filters.search, 400);



  const { data: allProducts = [], isLoading, error } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      const products = await base44.entities.Product.list('-created_date', 1000);
      return products.filter(p => {
        const stock = p.AvailableGross || p.available_quantity || 0;
        return stock > 0;
      });
    },
    retry: 2,
  });

  // Check URL for product ID or search query
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('produto');
    const searchQuery = urlParams.get('search');
    
    if (searchQuery) {
      setFilters(prev => ({ ...prev, search: searchQuery }));
    }
    
    if (productId && allProducts.length > 0) {
      const product = allProducts.find(p => p.id === productId);
      if (product) {
        setSelectedProduct(product);
        setIsModalOpen(true);
        window.history.replaceState({}, '', window.location.pathname);
      }
    }
  }, [allProducts]);

  // Extract unique filter options with counts
  const filterOptions = React.useMemo(() => {
    const types = {};
    const subTypes = {};
    const brands = {};
    const countries = {};
    const materials = {};

    allProducts.forEach(p => {
      if (p.Type) types[p.Type] = (types[p.Type] || 0) + 1;
      if (p.SubType) subTypes[p.SubType] = (subTypes[p.SubType] || 0) + 1;
      if (p.Brand) brands[p.Brand] = (brands[p.Brand] || 0) + 1;
      if (p.CountryOfOrigin) countries[p.CountryOfOrigin] = (countries[p.CountryOfOrigin] || 0) + 1;
      if (p.Materials) {
        const mats = p.Materials.split(',').map(m => m.trim());
        mats.forEach(m => materials[m] = (materials[m] || 0) + 1);
      }
    });

    return {
      types: Object.entries(types).sort(([a], [b]) => a.localeCompare(b)),
      subTypes: Object.entries(subTypes).sort(([a], [b]) => a.localeCompare(b)),
      brands: Object.entries(brands).sort(([a], [b]) => a.localeCompare(b)),
      countries: Object.entries(countries).sort(([a], [b]) => a.localeCompare(b)),
      materials: Object.entries(materials).sort(([a,countA], [b,countB]) => countB - countA).slice(0, 15)
    };
  }, [allProducts]);

  const filteredProducts = React.useMemo(() => {
    let result = allProducts;
    
    if (debouncedSearch) {
      const lowerQuery = debouncedSearch.toLowerCase();
      result = result.filter(product => 
        (product.Name || product.name || '').toLowerCase().includes(lowerQuery) ||
        (generateDisplayReference(product) || '').toLowerCase().includes(lowerQuery) || // Search by custom reference
        (product.ProdReference || product.friendly_code || '').toLowerCase().includes(lowerQuery) ||
        (product.Description || product.description || '').toLowerCase().includes(lowerQuery) ||
        (product.Brand || '').toLowerCase().includes(lowerQuery)
      );
    }
    
    if (filters.types.length > 0) {
      result = result.filter(p => filters.types.includes(p.Type));
    }
    if (filters.subTypes.length > 0) {
      result = result.filter(p => filters.subTypes.includes(p.SubType));
    }
    if (filters.brands.length > 0) {
      result = result.filter(p => filters.brands.includes(p.Brand));
    }
    if (filters.countries.length > 0) {
      result = result.filter(p => filters.countries.includes(p.CountryOfOrigin));
    }
    if (filters.materials.length > 0) {
      result = result.filter(p => {
        if (!p.Materials) return false;
        const productMats = p.Materials.split(',').map(m => m.trim());
        return filters.materials.some(m => productMats.includes(m));
      });
    }
    
    // Sorting
    if (sortBy === 'name-asc') {
      result.sort((a, b) => (a.Name || a.name || '').localeCompare(b.Name || b.name || ''));
    } else if (sortBy === 'name-desc') {
      result.sort((a, b) => (b.Name || b.name || '').localeCompare(a.Name || a.name || ''));
    } else if (sortBy === 'stock-high') {
      result.sort((a, b) => (b.AvailableGross || 0) - (a.AvailableGross || 0));
    } else if (sortBy === 'stock-low') {
      result.sort((a, b) => (a.AvailableGross || 0) - (b.AvailableGross || 0));
    } else if (sortBy === '-created_date') {
      result.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    }
    
    return result;
  }, [allProducts, debouncedSearch, filters, sortBy]);

  const paginatedProducts = React.useMemo(() => {
    const start = (page - 1) * pageSize;
    const end = start + pageSize;
    return filteredProducts.slice(start, end);
  }, [filteredProducts, page, pageSize]);

  const totalPages = Math.ceil(filteredProducts.length / pageSize);

  useEffect(() => {
    setPage(1);
  }, [debouncedSearch, filters, pageSize]);

  const toggleFilter = (category, value) => {
    setFilters(prev => {
      const current = prev[category];
      if (current.includes(value)) {
        return { ...prev, [category]: current.filter(v => v !== value) };
      } else {
        return { ...prev, [category]: [...current, value] };
      }
    });
  };

  const removeFilter = (category, value) => {
    setFilters(prev => ({
      ...prev,
      [category]: prev[category].filter(v => v !== value)
    }));
  };

  const clearAllFilters = () => {
    setFilters({
      search: '',
      types: [],
      subTypes: [],
      brands: [],
      countries: [],
      materials: []
    });
  };

  const activeFiltersCount = 
    filters.types.length + 
    filters.subTypes.length + 
    filters.brands.length + 
    filters.countries.length +
    filters.materials.length;

  const handleViewDetails = (product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  if (error) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center max-w-md px-4">
          <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h2 className="font-serif text-2xl font-bold text-charcoal mb-2">
            Erro ao Carregar Produtos
          </h2>
          <p className="text-gray-600 mb-6">
            Não foi possível carregar os produtos. Por favor, tente novamente.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 text-charcoal min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-gray-50 to-pink-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-charcoal">
              Catálogo de Produtos
            </h1>
            <p className="text-lg text-gray-600 mb-2">
              Descubra produtos únicos prontos para personalização
            </p>
            {!isLoading && (
              <p className="text-sm text-gray-500">
                {filteredProducts.length === allProducts.length ? (
                  <span>{allProducts.length} produtos disponíveis</span>
                ) : (
                  <span>Exibindo {filteredProducts.length} de {allProducts.length} produtos</span>
                )}
              </p>
            )}
          </motion.div>
        </div>
      </section>

      {/* Featured Products Carousel */}
      {!isLoading && allProducts.length > 0 && (
        <section className="py-8 bg-white border-b">
          <div className="max-w-7xl mx-auto px-4">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="h-5 w-5 text-primary" />
              <h2 className="font-semibold text-lg text-charcoal">Produtos em Destaque</h2>
            </div>
            <ProductCarousel products={allProducts} onViewDetails={handleViewDetails} />
          </div>
        </section>
      )}

      {/* Main Content */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Sidebar Filters */}
            <aside className="lg:w-64 flex-shrink-0">
              <Card className="sticky top-24 p-4 bg-white">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-charcoal flex items-center">
                    <SlidersHorizontal className="h-4 w-4 mr-2" />
                    Filtros
                    {activeFiltersCount > 0 && (
                      <Badge className="ml-2 bg-primary">{activeFiltersCount}</Badge>
                    )}
                  </h3>
                  {activeFiltersCount > 0 && (
                    <Button onClick={clearAllFilters} variant="ghost" size="sm" className="text-xs">
                      Limpar
                    </Button>
                  )}
                </div>

                {/* Search */}
                <div className="mb-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input 
                      placeholder="Buscar..."
                      value={filters.search}
                      onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                      className="pl-10 h-9 text-sm"
                    />
                  </div>
                </div>

                {/* Type */}
                <FilterSection title="Tipo">
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {filterOptions.types.map(([type, count]) => (
                      <label key={type} className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                        <Checkbox
                          checked={filters.types.includes(type)}
                          onCheckedChange={() => toggleFilter('types', type)}
                        />
                        <span className="text-sm flex-1">{type}</span>
                        <span className="text-xs text-gray-400">({count})</span>
                      </label>
                    ))}
                  </div>
                </FilterSection>

                {/* SubType */}
                <FilterSection title="Subtipo" defaultOpen={false}>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {filterOptions.subTypes.map(([subType, count]) => (
                      <label key={subType} className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                        <Checkbox
                          checked={filters.subTypes.includes(subType)}
                          onCheckedChange={() => toggleFilter('subTypes', subType)}
                        />
                        <span className="text-sm flex-1">{subType}</span>
                        <span className="text-xs text-gray-400">({count})</span>
                      </label>
                    ))}
                  </div>
                </FilterSection>

                {/* Brand */}
                <FilterSection title="Marca" defaultOpen={false}>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {filterOptions.brands.map(([brand, count]) => (
                      <label key={brand} className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                        <Checkbox
                          checked={filters.brands.includes(brand)}
                          onCheckedChange={() => toggleFilter('brands', brand)}
                        />
                        <span className="text-sm flex-1">{brand}</span>
                        <span className="text-xs text-gray-400">({count})</span>
                      </label>
                    ))}
                  </div>
                </FilterSection>

                {/* Materials */}
                <FilterSection title="Materiais" defaultOpen={false}>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {filterOptions.materials.map(([material, count]) => (
                      <label key={material} className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                        <Checkbox
                          checked={filters.materials.includes(material)}
                          onCheckedChange={() => toggleFilter('materials', material)}
                        />
                        <span className="text-sm flex-1 truncate" title={material}>{material}</span>
                        <span className="text-xs text-gray-400">({count})</span>
                      </label>
                    ))}
                  </div>
                </FilterSection>

                {/* Country */}
                <FilterSection title="País de Origem" defaultOpen={false}>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {filterOptions.countries.map(([country, count]) => (
                      <label key={country} className="flex items-center space-x-2 cursor-pointer hover:bg-gray-50 p-1 rounded">
                        <Checkbox
                          checked={filters.countries.includes(country)}
                          onCheckedChange={() => toggleFilter('countries', country)}
                        />
                        <span className="text-sm flex-1">{country}</span>
                        <span className="text-xs text-gray-400">({count})</span>
                      </label>
                    ))}
                  </div>
                </FilterSection>
              </Card>
            </aside>

            {/* Products Grid */}
            <div className="flex-1">
              {/* Active Filters Pills */}
              {activeFiltersCount > 0 && (
                <div className="mb-4 flex flex-wrap gap-2">
                  {filters.types.map(type => (
                    <Badge key={type} variant="secondary" className="flex items-center gap-1">
                      Tipo: {type}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => removeFilter('types', type)} />
                    </Badge>
                  ))}
                  {filters.subTypes.map(subType => (
                    <Badge key={subType} variant="secondary" className="flex items-center gap-1">
                      Subtipo: {subType}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => removeFilter('subTypes', subType)} />
                    </Badge>
                  ))}
                  {filters.brands.map(brand => (
                    <Badge key={brand} variant="secondary" className="flex items-center gap-1">
                      Marca: {brand}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => removeFilter('brands', brand)} />
                    </Badge>
                  ))}
                  {filters.materials.map(material => (
                    <Badge key={material} variant="secondary" className="flex items-center gap-1">
                      Material: {material}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => removeFilter('materials', material)} />
                    </Badge>
                  ))}
                  {filters.countries.map(country => (
                    <Badge key={country} variant="secondary" className="flex items-center gap-1">
                      Origem: {country}
                      <X className="h-3 w-3 cursor-pointer" onClick={() => removeFilter('countries', country)} />
                    </Badge>
                  ))}
                </div>
              )}

              {/* Toolbar */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 bg-white p-4 rounded-lg border">
                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-600">
                    {filteredProducts.length} produto{filteredProducts.length !== 1 ? 's' : ''}
                  </span>
                  <Select value={String(pageSize)} onValueChange={(v) => setPageSize(Number(v))}>
                    <SelectTrigger className="w-32 h-9">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="24">24 por página</SelectItem>
                      <SelectItem value="48">48 por página</SelectItem>
                      <SelectItem value="96">96 por página</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48 h-9">
                    <SelectValue placeholder="Ordenar por" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="-created_date">Mais Recentes</SelectItem>
                    <SelectItem value="name-asc">Nome (A-Z)</SelectItem>
                    <SelectItem value="name-desc">Nome (Z-A)</SelectItem>
                    <SelectItem value="stock-high">Maior Estoque</SelectItem>
                    <SelectItem value="stock-low">Menor Estoque</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Products Grid */}
              {isLoading ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {Array(8).fill(0).map((_, i) => (
                    <div key={i} className="bg-white rounded-lg animate-pulse border">
                      <div className="aspect-square bg-gray-200"></div>
                      <div className="p-4">
                        <div className="h-4 bg-gray-200 rounded mb-2"></div>
                        <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : paginatedProducts.length > 0 ? (
                <>
                  <motion.div 
                    layout 
                    className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
                  >
                    {paginatedProducts.map((product) => (
                      <ProductCard 
                        key={product.id} 
                        product={product}
                        onViewDetails={handleViewDetails}
                      />
                    ))}
                  </motion.div>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="flex justify-center items-center space-x-4 mt-8">
                      <Button 
                        variant="outline" 
                        onClick={() => setPage(p => Math.max(1, p - 1))}
                        disabled={page === 1}
                      >
                        <ChevronLeft className="h-4 w-4 mr-2" />
                        Anterior
                      </Button>
                      <span className="text-sm text-gray-600">
                        Página {page} de {totalPages}
                      </span>
                      <Button 
                        variant="outline" 
                        onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                        disabled={page >= totalPages}
                      >
                        Próxima
                        <ChevronRight className="h-4 w-4 ml-2" />
                      </Button>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-16 bg-white rounded-lg">
                  <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-600">Nenhum produto encontrado</p>
                  <p className="text-sm text-gray-500 mt-2">Tente ajustar os filtros de busca</p>
                  {activeFiltersCount > 0 && (
                    <Button onClick={clearAllFilters} variant="outline" className="mt-4">
                      Limpar todos os filtros
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <ProductDetailModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setTimeout(() => setSelectedProduct(null), 300);
        }}
      />
    </div>
  );
}