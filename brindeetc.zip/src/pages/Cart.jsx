import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  ShoppingCart, Trash2, Plus, Minus, ArrowRight,
  Package, CheckCircle, Loader2, Edit
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import ProductDetailModal from '../components/products/ProductDetailModal';

// Função para converter nomes de cores em código HEX
const getColorHex = (colorName) => {
  const colorMap = {
    'branco': '#FFFFFF', 'preto': '#000000', 'cinza': '#808080',
    'vermelho': '#FF0000', 'azul': '#0000FF', 'verde': '#00FF00',
    'amarelo': '#FFFF00', 'laranja': '#FFA500', 'rosa': '#FFC0CB',
    'roxo': '#800080', 'marrom': '#8B4513', 'bege': '#F5F5DC',
    'white': '#FFFFFF', 'black': '#000000', 'grey': '#808080', 'gray': '#808080',
    'red': '#FF0000', 'blue': '#0000FF', 'green': '#00FF00',
    'yellow': '#FFFF00', 'orange': '#FFA500', 'pink': '#FFC0CB',
    'purple': '#800080', 'brown': '#8B4513', 'navy': '#000080',
    'azul claro': '#ADD8E6', 'verde claro': '#90EE90', 'vermelho claro': '#FF6B6B',
    'cinza claro': '#D3D3D3', 'amarelo claro': '#FFFFE0', 'laranja claro': '#FFDAB9',
    'rosa claro': '#FFB6C1', 'light blue': '#ADD8E6', 'light green': '#90EE90',
    'light pink': '#FFB6C1', 'dourado': '#FFD700', 'prateado': '#C0C0C0',
  };
  
  const normalizedName = colorName?.toLowerCase().trim() || '';
  if (colorMap[normalizedName]) return colorMap[normalizedName];
  
  // Detectar padrão "X claro"
  const lightMatch = normalizedName.match(/^(.+)\s+claro$/);
  if (lightMatch) {
    const base = {
      'azul': '#ADD8E6', 'verde': '#90EE90', 'vermelho': '#FF6B6B',
      'rosa': '#FFB6C1', 'amarelo': '#FFFFE0', 'cinza': '#D3D3D3'
    };
    if (base[lightMatch[1]]) return base[lightMatch[1]];
  }
  
  return '#CCCCCC';
};

// Configuração da API do aplicativo interno
const INTERNAL_APP_CONFIG = {
  apiUrl: 'https://app.base44.com/api/apps/68d55a26ec02082aa6dd3d12/entities/Quote',
  apiKey: '36c3535b58334160a0287557dbab91ad'
};

// Função para criar orçamento no app interno
const createInternalQuote = async (quoteData, cartItems) => {
  try {
    console.log('🚀 Iniciando criação de orçamento no app interno...');
    
    // Formatar itens do carrinho com todos os campos obrigatórios
    const formattedItems = cartItems.map(item => ({
      name: item.product_name,
      product_reference: item.product_reference,
      quantity: item.quantity,
      unit_price: 0,
      total_price: 0,
      color: item.selected_color?.Name || 'N/A',
      customization: item.selected_customization?.title || 'N/A',
      notes: item.notes || '',
      image_url: item.product_image || '',
      description: item.product_description || ''
    }));

    // Dados do orçamento para o app interno
    const internalQuoteData = {
      quote_number: `WEB-${Date.now()}`,
      client_name: quoteData.name,
      client_email: quoteData.email || '',
      client_phone: quoteData.phone || '',
      product_name: cartItems.map(i => i.product_name).join(', '),
      delivery_date: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: formattedItems,
      custom_notes: `
Empresa: ${quoteData.company || 'N/A'}

=== DETALHES DOS PRODUTOS ===
${formattedItems.map((item, idx) => `
${idx + 1}. ${item.name} (Ref: ${item.product_reference})
   - Quantidade: ${item.quantity}
   - Cor: ${item.color}
   - Personalização: ${item.customization}
   - Imagem: ${item.image_url || 'N/A'}
   - Descrição: ${item.description || 'N/A'}
   ${item.notes ? `- Observações: ${item.notes}` : ''}
`).join('\n')}

⚠️ ATENÇÃO: Valores unitários e totais devem ser preenchidos manualmente
      `.trim(),
      status: 'pendente',
      urgency: 'normal',
      valid_until: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
    };

    console.log('📦 Dados a serem enviados:', internalQuoteData);

    const response = await fetch(INTERNAL_APP_CONFIG.apiUrl, {
      method: 'POST',
      headers: {
        'api_key': INTERNAL_APP_CONFIG.apiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(internalQuoteData)
    });

    console.log('📡 Status da resposta:', response.status, response.statusText);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ Erro na resposta da API:', errorText);
      throw new Error(`Erro na API: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log('✅ Orçamento criado no app interno com sucesso!');
    console.log('📄 Resposta completa:', result);
    
    return result;
  } catch (error) {
    console.error('❌ Erro ao criar orçamento no app interno:', error);
    console.error('Stack:', error.stack);
    // Não mostrar alerta - deixar silencioso para não atrapalhar o usuário
    return null;
  }
};

export default function CartPage() {
  const [cartItems, setCartItems] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [editingCartItem, setEditingCartItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const [checkoutForm, setCheckoutForm] = useState({
    name: '',
    company: '',
    email: '',
    whatsapp: ''
  });

  useEffect(() => {
    loadCart();
  }, []);

  const getSessionId = () => {
    return localStorage.getItem('cart_session_id') || '';
  };

  const loadCart = async () => {
    setIsLoading(true);
    try {
      const sessionId = getSessionId();
      if (sessionId) {
        const items = await base44.entities.CartItem.filter({ session_id: sessionId }, '-created_date');
        setCartItems(items);
        localStorage.setItem('cart_count', items.length.toString());
      }
    } catch (error) {
      console.error('Erro ao carregar carrinho:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateQuantity = async (item, delta) => {
    const newQuantity = Math.max(1, item.quantity + delta);
    try {
      await base44.entities.CartItem.update(item.id, { quantity: newQuantity });
      loadCart();
    } catch (error) {
      console.error('Erro ao atualizar quantidade:', error);
    }
  };

  const removeItem = async (itemId) => {
    if (!confirm('Deseja remover este item do carrinho?')) return;
    
    try {
      await base44.entities.CartItem.delete(itemId);
      loadCart();
      window.dispatchEvent(new Event('cartUpdated'));
    } catch (error) {
      console.error('Erro ao remover item:', error);
    }
  };

  const handleEditItem = async (item) => {
    try {
      const products = await base44.entities.Product.filter({ ProdReference: item.product_reference });
      if (products.length > 0) {
        setEditingProduct(products[0]);
        setEditingCartItem(item);
        setIsModalOpen(true);
      }
    } catch (error) {
      console.error('Erro ao carregar produto:', error);
    }
  };

  const handleCheckout = async (e) => {
    e.preventDefault();
    setIsCheckingOut(true);

    try {
      // Formatar detalhes dos produtos
      const productsDetails = cartItems.map((item, index) => {
        let details = `\n${index + 1}. ${item.product_name} (Ref: ${item.product_reference})`;
        details += `\n   Quantidade: ${item.quantity} unidades`;
        
        if (item.selected_color) {
          details += `\n   Cor: ${item.selected_color.Name}`;
        }
        
        if (item.selected_customization) {
          details += `\n   Personalização: ${item.selected_customization.title} (${item.selected_customization.code})`;
        }
        
        if (item.notes) {
          details += `\n   Observações: ${item.notes}`;
        }
        
        return details;
      }).join('\n');

      // Criar solicitação de orçamento LOCAL
      const quoteData = {
        name: checkoutForm.name,
        company: checkoutForm.company,
        email: checkoutForm.email,
        phone: checkoutForm.whatsapp,
        event_type: 'corporativo',
        budget_range: 'consultar',
        message: `Solicitação via carrinho online\n\n=== PRODUTOS DO CARRINHO ===${productsDetails}`
      };

      console.log('💾 Criando orçamento local...');
      await base44.entities.QuoteRequest.create(quoteData);
      console.log('✅ Orçamento local criado!');

      // 🚀 Criar orçamento no aplicativo interno
      console.log('🔄 Iniciando sincronização com app interno...');
      await createInternalQuote(quoteData, cartItems);

      // Criar link do WhatsApp
      const whatsappNumber = '5511999999999'; // ALTERAR PARA SEU NÚMERO REAL
      const whatsappLink = `https://wa.me/${whatsappNumber}`;

      // Enviar e-mail APENAS para o cliente (silencioso em caso de erro)
      if (checkoutForm.email) {
        const emailBody = `
Olá ${checkoutForm.name}!

Recebemos sua solicitação de orçamento e agradecemos pela confiança! ✨

Nossa equipe está analisando seu pedido com atenção e retornaremos em breve com todas as informações detalhadas.

=== RESUMO DO SEU PEDIDO ===
${productsDetails}

Total de itens: ${cartItems.length}
Total de unidades: ${cartItems.reduce((sum, item) => sum + item.quantity, 0)}

---

💬 Tem alguma dúvida ou gostaria de conversar conosco?
Entre em contato via WhatsApp: ${whatsappLink}

Atenciosamente,
Equipe Brind.etc
Presentes que Contam Histórias
        `.trim();

        try {
          console.log('📧 Enviando e-mail...');
          await base44.integrations.Core.SendEmail({
            to: checkoutForm.email,
            subject: 'Recebemos seu orçamento - Brind.etc',
            body: emailBody
          });
          console.log('✅ E-mail enviado!');
        } catch (emailError) {
          console.log('⚠️ E-mail não enviado (continua normalmente):', emailError.message);
          // Não bloqueia o checkout - orçamento já foi criado
        }
      }

      // Limpar carrinho
      console.log('🗑️ Limpando carrinho...');
      for (const item of cartItems) {
        await base44.entities.CartItem.delete(item.id);
      }

      localStorage.setItem('cart_count', '0');
      window.dispatchEvent(new Event('cartUpdated'));

      setCheckoutSuccess(true);
      setCartItems([]);
      console.log('✅ Processo de checkout concluído!');

    } catch (error) {
      console.error('❌ Erro ao finalizar pedido:', error);
      alert('Erro ao enviar orçamento. Por favor, tente novamente.');
    } finally {
      setIsCheckingOut(false);
    }
  };

  if (checkoutSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center"
        >
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="h-10 w-10 text-green-600" />
            </div>
            <h1 className="text-2xl font-serif font-bold text-charcoal mb-4">
              Orçamento Enviado com Sucesso!
            </h1>
            <p className="text-gray-600 mb-2">
              Recebemos sua solicitação!
            </p>
            <p className="text-sm text-gray-500 mb-6">
              Enviamos um e-mail de confirmação com todos os detalhes. Nossa equipe retornará em breve.
            </p>
            <Button 
              onClick={() => window.location.href = '/'}
              className="bg-primary hover:bg-primary/90 w-full"
            >
              Voltar para Home
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-charcoal mb-2">
            Seu Carrinho de Cotação
          </h1>
          <p className="text-gray-600">
            Revise os produtos e finalize sua solicitação de orçamento
          </p>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <Loader2 className="h-12 w-12 animate-spin mx-auto text-primary mb-4" />
            <p className="text-gray-600">Carregando carrinho...</p>
          </div>
        ) : cartItems.length === 0 ? (
          <div className="text-center py-16">
            <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-charcoal mb-2">
              Seu carrinho está vazio
            </h2>
            <p className="text-gray-600 mb-6">
              Adicione produtos para solicitar um orçamento
            </p>
            <Button 
              onClick={() => window.location.href = '/produtos'}
              className="bg-primary hover:bg-primary/90"
            >
              Ver Catálogo
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-4">
              <AnimatePresence>
                {cartItems.map((item) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex gap-6">
                          <img
                            src={item.product_image}
                            alt={item.product_name}
                            className="w-24 h-24 object-contain bg-gray-50 rounded-lg flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity"
                            onClick={() => handleEditItem(item)}
                          />
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between mb-2">
                              <div className="flex-1 cursor-pointer" onClick={() => handleEditItem(item)}>
                                <h3 className="font-semibold text-lg text-charcoal mb-1 hover:text-primary transition-colors">
                                  {item.product_name}
                                </h3>
                                <p className="text-sm text-gray-500">
                                  Ref: {item.product_reference}
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditItem(item)}
                                className="text-gray-400 hover:text-primary"
                                title="Editar produto"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            </div>

                            <div className="space-y-2 mb-4">
                              {item.selected_color && (
                                <div className="flex items-center gap-2">
                                  <div
                                    className="w-5 h-5 rounded-full border border-gray-300"
                                    style={{ backgroundColor: item.selected_color.HexCode || getColorHex(item.selected_color.Name) }}
                                  />
                                  <span className="text-sm text-gray-600">
                                    Cor: {item.selected_color.Name}
                                  </span>
                                </div>
                              )}

                              {item.selected_customization && (
                                <div>
                                  <Badge variant="outline" className="text-xs">
                                    {item.selected_customization.title}
                                  </Badge>
                                </div>
                              )}

                              {item.notes && (
                                <p className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
                                  {item.notes}
                                </p>
                              )}
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => updateQuantity(item, -1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <span className="text-sm font-medium w-12 text-center">
                                  {item.quantity}
                                </span>
                                <Button
                                  variant="outline"
                                  size="icon"
                                  className="h-8 w-8"
                                  onClick={() => updateQuantity(item, 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>

                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeItem(item.id)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Remover
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            {/* Checkout Form */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardContent className="p-6">
                  <h2 className="text-xl font-serif font-bold text-charcoal mb-4">
                    Finalizar Solicitação
                  </h2>

                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-gray-600">Total de produtos:</span>
                      <span className="font-semibold">{cartItems.length}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Total de unidades:</span>
                      <span className="font-semibold">
                        {cartItems.reduce((sum, item) => sum + item.quantity, 0)}
                      </span>
                    </div>
                  </div>

                  <Separator className="my-6" />

                  <form onSubmit={handleCheckout} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Nome completo *</Label>
                      <Input
                        id="name"
                        value={checkoutForm.name}
                        onChange={(e) => setCheckoutForm(prev => ({ ...prev, name: e.target.value }))}
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="company">Empresa</Label>
                      <Input
                        id="company"
                        value={checkoutForm.company}
                        onChange={(e) => setCheckoutForm(prev => ({ ...prev, company: e.target.value }))}
                        placeholder="Opcional"
                      />
                    </div>

                    <div>
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        value={checkoutForm.email}
                        onChange={(e) => setCheckoutForm(prev => ({ ...prev, email: e.target.value }))}
                        placeholder="Opcional"
                      />
                    </div>

                    <div>
                      <Label htmlFor="whatsapp">WhatsApp *</Label>
                      <Input
                        id="whatsapp"
                        value={checkoutForm.whatsapp}
                        onChange={(e) => setCheckoutForm(prev => ({ ...prev, whatsapp: e.target.value }))}
                        placeholder="(11) 99999-9999"
                        required
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Para qualquer dúvida, entre em contato via WhatsApp
                      </p>
                    </div>

                    <Button
                      type="submit"
                      disabled={isCheckingOut}
                      className="w-full bg-primary hover:bg-primary/90"
                      size="lg"
                    >
                      {isCheckingOut ? (
                        <>
                          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                          Enviando...
                        </>
                      ) : (
                        <>
                          Solicitar Orçamento
                          <ArrowRight className="ml-2 h-5 w-5" />
                        </>
                      )}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      {/* Product Edit Modal */}
      {editingProduct && (
        <ProductDetailModal
          product={editingProduct}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setEditingProduct(null);
            setEditingCartItem(null);
            loadCart();
          }}
          editingCartItem={editingCartItem}
        />
      )}
    </div>
  );
}