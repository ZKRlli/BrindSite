
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Menu, X, Instagram, ShoppingCart } from "lucide-react";
import FloatingContactButton from "@/components/FloatingContactButton";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

const navigationItems = [
  { title: "Início", url: createPageUrl("Home") },
  { title: "Sobre Nós", url: createPageUrl("About") },
  { title: "Portfolio", url: createPageUrl("Portfolio") },
  { title: "Produtos", url: createPageUrl("Products") },
  { title: "Nosso Processo", url: createPageUrl("Services") },
  { title: "Blog.etc", url: createPageUrl("Blog") },
];

const WHATSAPP_NUMBER = "5511998148242";
const WHATSAPP_MESSAGE = encodeURIComponent("Olá! Vim pelo site e gostaria de mais informações.");
const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`;

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [cartCount, setCartCount] = React.useState(0);

  React.useEffect(() => {
    const count = parseInt(localStorage.getItem('cart_count') || '0');
    setCartCount(count);

    const handleCartUpdate = () => {
      const newCount = parseInt(localStorage.getItem('cart_count') || '0');
      setCartCount(newCount);
    };

    window.addEventListener('cartUpdated', handleCartUpdate);
    return () => window.removeEventListener('cartUpdated', handleCartUpdate);
  }, []);

  React.useEffect(() => {
    // Set favicon dynamically
    const link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link.type = 'image/png';
    link.rel = 'icon';
    link.href = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68d94c0b420c67a83c3c78fe/d5e96ab5c_BrindLogo_Final-03-03.png';
    document.head.appendChild(link);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <style jsx>{`
        :root {
          --primary-pink: #E91E8C;
          --secondary-purple: #A855F7;
          --dark-bg: #1a1a1a;
          --charcoal: #2D3748;
          --light-grey: #F7FAFC;
        }
        
        body {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        .font-serif {
          font-family: 'Playfair Display', Georgia, serif;
        }
        
        .text-primary {
          color: var(--primary-pink);
        }
        
        .bg-primary {
          background-color: var(--primary-pink);
        }
        
        .bg-gradient-pink-purple {
          background: linear-gradient(135deg, #E91E8C 0%, #A855F7 100%);
        }
        
        .text-charcoal {
          color: var(--charcoal);
        }

        .btn-cta {
          background: linear-gradient(135deg, #E91E8C 0%, #A855F7 100%);
          box-shadow: 0 4px 14px 0 rgba(233, 30, 140, 0.4);
          transition: all 0.3s ease;
        }

        .btn-cta:hover {
          box-shadow: 0 6px 20px 0 rgba(233, 30, 140, 0.6);
          transform: translateY(-2px);
        }
      `}</style>

      {/* Navigation */}
      <nav className="bg-white border-b border-gray-100 fixed w-full top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex-shrink-0">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68a4926f7506dfd8882872d0/a4f1876eb_BrindLogo_Final-02.png" 
                alt="Brind.etc" 
                className="h-10 w-auto"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-8">
              {navigationItems.map((item) => (
                <Link
                  key={item.title}
                  to={item.url}
                  className={`text-sm font-medium transition-colors hover:text-primary ${
                    location.pathname === item.url ? 'text-primary' : 'text-charcoal'
                  }`}
                >
                  {item.title}
                </Link>
              ))}
            </div>

            {/* CTA Button + Cart */}
            <div className="hidden lg:flex items-center space-x-4">
              <Link to={createPageUrl("Cart")}>
                <Button variant="ghost" size="icon" className="relative hover:bg-primary/10">
                  <ShoppingCart className="h-5 w-5" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-semibold shadow-lg">
                      {cartCount}
                    </span>
                  )}
                </Button>
              </Link>
              <Link to={createPageUrl("Contact")}>
                <Button className="btn-cta text-white font-semibold px-6 py-2 rounded-full border-0">
                  Peça um Orçamento
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button + Cart */}
            <div className="flex items-center gap-2 lg:hidden">
              <Link to={createPageUrl("Cart")}>
                <Button variant="ghost" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-semibold">
                      {cartCount}
                    </span>
                  )}
                </Button>
              </Link>
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6 text-charcoal" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                  <SheetHeader>
                    <SheetTitle>
                      <img 
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68a4926f7506dfd8882872d0/07d602208_BrindLogo_Final-03.png" 
                        alt="Brind.etc" 
                        className="h-8 w-auto"
                      />
                    </SheetTitle>
                  </SheetHeader>
                  <div className="flex flex-col space-y-4 mt-8">
                    {navigationItems.map((item) => (
                      <Link
                        key={item.title}
                        to={item.url}
                        onClick={() => setMobileMenuOpen(false)}
                        className={`text-base font-medium py-3 px-4 rounded-lg transition-colors ${
                          location.pathname === item.url 
                            ? 'bg-primary/10 text-primary' 
                            : 'text-charcoal hover:bg-gray-50'
                        }`}
                      >
                        {item.title}
                      </Link>
                    ))}
                    <div className="pt-4 border-t border-gray-100">
                      <Link to={createPageUrl("Contact")} onClick={() => setMobileMenuOpen(false)}>
                        <Button className="w-full btn-cta text-white font-semibold rounded-full border-0">
                          Peça um Orçamento
                        </Button>
                      </Link>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-20">
        {children}
      </main>

      {/* Floating Contact Button */}
      <FloatingContactButton />

      {/* CTA Section before Footer */}
      <section className="py-20 bg-gradient-pink-purple text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-6">
            Pronto para Criar Memórias Inesquecíveis?
          </h2>
          <p className="text-lg mb-8 text-white/90 max-w-2xl mx-auto">
            Transforme seus próximos eventos e relacionamentos corporativos com presentes únicos que realmente fazem a diferença. Nossa equipe está pronta para tornar suas ideias realidade.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link to={createPageUrl("Contact")}>
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100 px-8 rounded-full font-semibold shadow-xl hover:shadow-2xl transition-all hover:scale-105">
                Solicitar Orçamento →
              </Button>
            </Link>
            <Link to={createPageUrl("Portfolio")}>
              <Button size="lg" className="bg-white text-primary hover:bg-gray-100 px-8 rounded-full font-semibold shadow-xl hover:shadow-2xl transition-all hover:scale-105">
                Ver Portfólio
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1a1a1a] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68a4926f7506dfd8882872d0/a4f1876eb_BrindLogo_Final-02.png" 
                alt="Brind.etc" 
                className="h-10 w-auto mb-4 brightness-0 invert"
              />
              <p className="text-gray-400 text-sm leading-relaxed mb-4">
                Transformamos presentes corporativos e eventos em experiências memoráveis através de histórias únicas.
              </p>
              <div className="flex items-center space-x-4">
                <a href="https://www.instagram.com/brind.etc" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-primary transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-white mb-4">Navegação</h3>
              <div className="space-y-2">
                {navigationItems.map((item) => (
                  <Link
                    key={item.title}
                    to={item.url}
                    className="block text-sm text-gray-400 hover:text-primary transition-colors"
                  >
                    {item.title}
                  </Link>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-white mb-4">Contato</h3>
              <div className="space-y-2 text-sm text-gray-400">
                <p>📧 contato@brind.etc.br</p>
                <a href={WHATSAPP_LINK} target="_blank" rel="noopener noreferrer" className="block hover:text-primary transition-colors">
                  📱 +55 11 99814-8242
                </a>
                <p className="text-xs text-gray-500 mt-2">Seg - Sex: 9h às 18h</p>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-gray-500">
            <p>© 2025 Brind.etc. Todos os direitos reservados.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-primary transition-colors">Política de Privacidade</a>
              <a href="#" className="hover:text-primary transition-colors">Termos de Uso</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
