import React from 'react';
import { motion } from 'framer-motion';
import { 
  Lightbulb, Palette, Package, Heart, PenTool, Search, Smile,
  Printer, Zap, Layers, Droplet, Sun, CircleDot, Brush, Shirt, Tag, Thermometer, Combine
} from 'lucide-react';
import { Badge } from "@/components/ui/badge";

export default function ServicesPage() {
  const processSteps = [
    {
      icon: Lightbulb,
      title: "1. Consulta & Briefing",
      description: "Tudo começa com uma conversa. Ouvimos atentamente suas ideias, objetivos e orçamento para entender profundamente a alma do seu projeto."
    },
    {
      icon: Palette,
      title: "2. Design & Prototipagem",
      description: "Nossa equipe criativa transforma o briefing em conceitos visuais. Desenvolvemos protótipos para que você possa ver e sentir o produto antes da produção final."
    },
    {
      icon: PenTool,
      title: "3. Refinamento & Aprovação",
      description: "Trabalhamos em conjunto com você para refinar cada detalhe. Ajustamos cores, materiais e acabamentos até alcançarmos a perfeição e sua aprovação final."
    },
    {
      icon: Package,
      title: "4. Produção & Qualidade",
      description: "Com o design aprovado, iniciamos a produção. Utilizamos materiais de alta qualidade e um controle rigoroso para garantir que cada peça seja impecável."
    },
    {
      icon: Heart,
      title: "5. Embalagem & Entrega",
      description: "A experiência se completa com uma embalagem especial. Cuidamos da logística para que seus presentes cheguem com segurança e no prazo, prontos para encantar."
    },
  ];

  const services = [
    { icon: Search, title: "Curadoria de Materiais", description: "Pesquisamos e selecionamos os melhores materiais que se alinham com seu projeto e orçamento." },
    { icon: PenTool, title: "Design de Produto Exclusivo", description: "Criação de produtos do zero, totalmente personalizados para sua marca ou evento." },
    { icon: Smile, title: "Gestão de Projeto de Ponta a Ponta", description: "Cuidamos de todas as etapas, da ideia inicial à entrega, para sua total tranquilidade." }
  ];

  const customizationTechniques = [
    { code: "DGL", title: "Impressão Digital", description: "Impressão com qualidade fotográfica, ideal para detalhes finos em superfícies planas.", icon: Printer },
    { code: "EDB", title: "Bordado", description: "Técnica que personaliza tecidos com grande qualidade, perfeição e um acabamento sofisticado.", icon: Combine },
    { code: "LSR", title: "Laser", description: "Gravação de alta precisão em baixo-relevo, para metais (fibra ótica) ou madeira e cortiça (CO²).", icon: Zap },
    { code: "DTT", title: "Transfer Digital", description: "Aplicação por calor e pressão de uma impressão digital em full color, transferida de um papel especial.", icon: Layers },
    { code: "HTS", title: "Hot Stamping", description: "Prensa quente sobre couro ou similares, com opção de acabamento metalizado (dourado/prateado).", icon: PenTool },
    { code: "PDP", title: "Tampografia", description: "Técnica ideal para pequenos objetos e formas curvas, transferindo tinta com um tampão de silicone flexível.", icon: Droplet },
    { code: "DUV", title: "UV Digital", description: "Impressão direta sobre materiais rígidos com secagem instantânea por luz ultravioleta.", icon: Sun },
    { code: "LAS", title: "Laser Circular", description: "Gravação a laser de alta precisão otimizada para aplicação em superfícies curvas e cilíndricas.", icon: CircleDot },
    { code: "SCR", title: "Silk Screen", description: "Impressão por tela para cores sólidas e vibrantes em uma vasta gama de materiais.", icon: Brush },
    { code: "TRS", title: "Transfer", description: "Aplicação por calor em produtos não planos, como mochilas, usando uma impressão transferida de papel.", icon: Layers },
    { code: "SRC", title: "Silk Screen Circular", description: "Processo de silk screen adaptado para impressão em produtos com formato circular.", icon: CircleDot },
    { code: "TXP", title: "Silk Screen Têxtil", description: "Processo de silk screen focado em tecidos, ideal para camisetas e outros produtos têxteis.", icon: Shirt },
    { code: "STI", title: "Etiquetas", description: "Impressão de etiquetas em vinil com qualidade fotográfica e grande variedade de tamanhos e formas.", icon: Tag },
    { code: "UVC", title: "UV Circular", description: "Impressão UV digital que cobre toda a circunferência de objetos cilíndricos.", icon: Sun },
    { code: "SUB", title: "Sublimação", description: "A tinta é transferida para o produto através de calor, resultando em cores vivas e duradouras em tecidos e resinas.", icon: Thermometer },
  ];

  return (
    <div className="bg-white text-charcoal">
      {/* Hero Section */}
      <section className="bg-gray-50 text-center py-20 lg:py-28">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl mx-auto px-4"
        >
          <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Nosso Processo
          </h1>
          <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
            Da primeira ideia ao momento da entrega, cada etapa do nosso trabalho é executada com cuidado, criatividade e precisão.
          </p>
        </motion.div>
      </section>

      {/* Customization Techniques Section - MOVED TO TOP */}
      <section className="py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Serviços de Personalização de Qualidade
            </h2>
            <p className="text-gray-600 text-lg max-w-3xl mx-auto">
              Dominamos uma ampla gama de técnicas de personalização para garantir que o acabamento do seu projeto seja impecável e perfeitamente alinhado à sua visão.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {customizationTechniques.map((tech) => (
              <motion.div
                key={tech.code}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="bg-gray-50/70 p-6 rounded-xl flex flex-col items-start"
              >
                <div className="flex items-center justify-between w-full mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary/10 text-primary rounded-lg flex items-center justify-center">
                      <tech.icon className="w-6 h-6" />
                    </div>
                    <h3 className="text-lg font-semibold text-charcoal">{tech.title}</h3>
                  </div>
                  <Badge variant="outline" className="border-gray-300 text-gray-500 font-mono text-xs">{tech.code}</Badge>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed flex-grow">
                  {tech.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Services Section */}
      <section className="bg-gray-50 py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-16">Serviços Chave</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: index * 0.1 }}
                className="bg-white p-8 rounded-xl shadow-sm hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-primary/10 text-primary rounded-full flex items-center justify-center mx-auto mb-6">
                  <service.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-semibold mb-3">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Steps Section - MOVED TO BOTTOM */}
      <section className="py-20 lg:py-28">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-charcoal mb-4">
              Nosso Processo Criativo
            </h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Do conceito à entrega, cada etapa é cuidadosamente planejada para garantir resultados excepcionais
            </p>
          </div>
          <div className="relative border-l-2 border-gray-200 ml-6 lg:ml-0 lg:pl-0">
            {processSteps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7 }}
                className="mb-16 pl-12 relative"
              >
                <div className="absolute -left-6 top-0 w-12 h-12 bg-primary/10 text-primary rounded-full flex items-center justify-center">
                  <step.icon className="w-6 h-6" />
                </div>
                <h2 className="font-serif text-2xl font-bold mb-3">{step.title}</h2>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}